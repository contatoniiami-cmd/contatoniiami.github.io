'use client'

import { useSyncExternalStore } from 'react'
import { useTheme } from 'next-themes'
import { Check, Eye, Monitor, Moon, RotateCcw, Settings2, Sun } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  BG_PRESETS,
  bgCss,
  getSettings,
  getServerSettings,
  resetReveals,
  revealAll,
  subscribeSettings,
  updateSettings,
  type BgPreset,
} from '@/lib/settings-store'
import { getIceberg, getServerIceberg, subscribeIceberg } from '@/lib/iceberg-store'
import { FontPicker } from '@/components/iceberg/font-picker'
import { ColorPicker } from '@/components/iceberg/color-picker'
import { useMounted } from '@/hooks/use-mounted'

const THEME_OPTIONS = [
  { value: 'light', name: 'Claro', icon: Sun },
  { value: 'dark', name: 'Escuro', icon: Moon },
  { value: 'system', name: 'Sistema', icon: Monitor },
] as const

/** Painel de opções: tema, fundo, elementos do iceberg e modo de exibição */
export function SettingsPanel() {
  const settings = useSyncExternalStore(subscribeSettings, getSettings, getServerSettings)
  const data = useSyncExternalStore(subscribeIceberg, getIceberg, getServerIceberg)
  const { theme, resolvedTheme, setTheme } = useTheme()
  const mounted = useMounted()

  const dark = mounted ? resolvedTheme === 'dark' : false
  const activeTheme = mounted ? theme : undefined

  const total = data.layers.reduce((acc, l) => acc + l.topics.length, 0)
  const revealedCount = data.layers.reduce(
    (acc, l) => acc + l.topics.filter((t) => settings.revealedIds.includes(t.id)).length,
    0,
  )
  const pct = total > 0 ? Math.round((revealedCount / total) * 100) : 0

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" title="Opções e personalização">
          <Settings2 className="size-4" />
          <span className="hidden sm:inline">Opções</span>
        </Button>
      </SheetTrigger>

      <SheetContent
        side="right"
        className="flex w-[21rem] flex-col gap-0 overflow-y-auto sm:max-w-[21rem]"
      >
        <SheetHeader className="border-b border-border">
          <SheetTitle className="flex items-center gap-2 text-base">
            <Settings2 className="size-4 text-teal-600 dark:text-teal-400" aria-hidden />
            Opções do iceberg
          </SheetTitle>
          <SheetDescription>
            Personalize a aparência e o modo de exibição — tudo salvo automaticamente.
          </SheetDescription>
        </SheetHeader>

        <div className="flex flex-col gap-5 p-4 pb-10">
          {/* ------------------ Aparência ------------------ */}
          <section className="flex flex-col gap-3" aria-labelledby="opt-aparencia">
            <h3 id="opt-aparencia" className="text-sm font-semibold">
              Aparência
            </h3>

            <div
              role="radiogroup"
              aria-label="Tema do site"
              className="grid grid-cols-3 gap-1 rounded-lg border border-border bg-muted/40 p-1"
            >
              {THEME_OPTIONS.map((opt) => {
                const active = activeTheme === opt.value
                return (
                  <button
                    key={opt.value}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => setTheme(opt.value)}
                    className={`flex flex-col items-center gap-1 rounded-md px-2 py-2 text-xs font-medium transition-colors ${
                      active
                        ? 'bg-primary text-primary-foreground shadow-sm'
                        : 'text-muted-foreground hover:bg-accent hover:text-foreground'
                    }`}
                  >
                    <opt.icon className="size-4" aria-hidden />
                    {opt.name}
                  </button>
                )
              })}
            </div>

            <div className="flex flex-col gap-2">
              <p className="text-xs font-medium text-muted-foreground">Fundo da página</p>
              <div className="grid grid-cols-3 gap-2">
                {(Object.keys(BG_PRESETS) as Exclude<BgPreset, 'custom'>[]).map((key) => {
                  const preset = BG_PRESETS[key]
                  const selected = settings.bgPreset === key
                  return (
                    <button
                      key={key}
                      type="button"
                      title={preset.hint}
                      aria-pressed={selected}
                      onClick={() => updateSettings((s) => void (s.bgPreset = key))}
                      className={`relative flex h-16 flex-col justify-end overflow-hidden rounded-lg border transition-all ${
                        selected
                          ? 'border-teal-500 ring-2 ring-teal-500/40'
                          : 'border-border hover:border-teal-400'
                      }`}
                    >
                      <span
                        className="absolute inset-0"
                        style={{ background: bgCss(key, '', dark) }}
                        aria-hidden
                      />
                      <span className="relative m-1 rounded bg-background/85 px-1 py-0.5 text-[10px] font-medium text-foreground">
                        {preset.name}
                      </span>
                      {selected && (
                        <Check
                          className="absolute left-1 top-1 size-3.5 text-teal-600 drop-shadow-sm dark:text-teal-300"
                          aria-hidden
                        />
                      )}
                    </button>
                  )
                })}

                <button
                  type="button"
                  aria-pressed={settings.bgPreset === 'custom'}
                  onClick={() => updateSettings((s) => void (s.bgPreset = 'custom'))}
                  className={`relative flex h-16 flex-col justify-end overflow-hidden rounded-lg border transition-all ${
                    settings.bgPreset === 'custom'
                      ? 'border-teal-500 ring-2 ring-teal-500/40'
                      : 'border-border hover:border-teal-400'
                  }`}
                >
                  <span
                    className="absolute inset-0"
                    style={{ background: settings.bgCustom || '#134e4a' }}
                    aria-hidden
                  />
                  <span className="relative m-1 rounded bg-background/85 px-1 py-0.5 text-[10px] font-medium text-foreground">
                    Personalizada
                  </span>
                  {settings.bgPreset === 'custom' && (
                    <Check
                      className="absolute left-1 top-1 size-3.5 text-teal-600 drop-shadow-sm dark:text-teal-300"
                      aria-hidden
                    />
                  )}
                </button>
              </div>

              {settings.bgPreset === 'custom' && (
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={settings.bgCustom}
                    aria-label="Cor de fundo personalizada"
                    onChange={(e) => updateSettings((s) => void (s.bgCustom = e.target.value))}
                    className="size-9 shrink-0 cursor-pointer rounded-md border border-border bg-transparent p-1"
                  />
                  <Input
                    value={settings.bgCustom}
                    aria-label="Código da cor de fundo"
                    onChange={(e) => updateSettings((s) => void (s.bgCustom = e.target.value))}
                    className="h-9 font-mono text-xs"
                    placeholder="#134e4a"
                  />
                </div>
              )}
            </div>
          </section>

          <Separator />

          {/* ------------------ Fontes ------------------ */}
          <section className="flex flex-col gap-1" aria-labelledby="opt-fontes">
            <h3 id="opt-fontes" className="mb-1 text-sm font-semibold">
              Fontes
            </h3>

            <RowSwitch
              label="Interligar fontes dos tópicos"
              desc="Ativado: todos os tópicos usam a mesma fonte. Desativado: cada tópico escolhe a sua no formulário de edição"
              checked={settings.linkTopicFonts}
              onCheckedChange={(v) => updateSettings((s) => void (s.linkTopicFonts = v))}
            />

            <div className="mt-2 flex flex-col gap-2 rounded-lg border border-border bg-muted/40 p-3">
              <p className="text-xs font-medium text-muted-foreground">
                {settings.linkTopicFonts
                  ? 'Fonte aplicada a todos os tópicos'
                  : 'Fonte padrão dos tópicos (cada um pode ter a sua)'}
              </p>
              <FontPicker
                value={settings.topicFont}
                onChange={(fc) => updateSettings((s) => void (s.topicFont = fc))}
                idPrefix="opt-font"
              />
            </div>
          </section>

          <Separator />

          {/* ------------------ Cores do texto ------------------ */}
          <section className="flex flex-col gap-1" aria-labelledby="opt-cores">
            <h3 id="opt-cores" className="mb-1 text-sm font-semibold">
              Cores do texto
            </h3>

            <RowSwitch
              label="Interligar cores dos tópicos"
              desc="Ativado: todos os tópicos usam a mesma cor. Desativado: cada tópico escolhe a sua no formulário de edição"
              checked={settings.linkTopicColors}
              onCheckedChange={(v) => updateSettings((s) => void (s.linkTopicColors = v))}
            />

            <div className="mt-2 flex flex-col gap-2 rounded-lg border border-border bg-muted/40 p-3">
              <p className="text-xs font-medium text-muted-foreground">
                {settings.linkTopicColors
                  ? 'Cor aplicada a todos os tópicos'
                  : 'Cor padrão dos tópicos (cada um pode ter a sua)'}
              </p>
              <ColorPicker
                value={settings.topicColor}
                onChange={(cc) => updateSettings((s) => void (s.topicColor = cc))}
                idPrefix="opt-color"
              />
              <p className="text-[11px] leading-snug text-muted-foreground">
                Cada cor tem um par claro/escuro — o texto continua legível no modo claro e no
                noturno, do topo do iceberg ao fundo.
              </p>
            </div>
          </section>

          <Separator />

          {/* ------------------ Elementos ------------------ */}
          <section className="flex flex-col gap-1" aria-labelledby="opt-elementos">
            <h3 id="opt-elementos" className="mb-1 text-sm font-semibold">
              Elementos do iceberg
            </h3>

            <RowSwitch
              label="Nível do mar"
              desc="Linha que marca a superfície"
              checked={settings.showSeaLevel}
              onCheckedChange={(v) => updateSettings((s) => void (s.showSeaLevel = v))}
            />
            {settings.showSeaLevel && (
              <Input
                value={settings.seaLevelLabel}
                aria-label="Texto do nível do mar"
                onChange={(e) => updateSettings((s) => void (s.seaLevelLabel = e.target.value))}
                className="mt-1.5 h-9 text-sm"
                placeholder="nível do mar"
              />
            )}

            <RowSwitch
              label="Profundidade"
              desc="Rótulo de metros em cada camada"
              checked={settings.showDepth}
              onCheckedChange={(v) => updateSettings((s) => void (s.showDepth = v))}
            />

            <RowSwitch
              label="Memes"
              desc="Imagens de reação ao lado de cada camada, como nos icebergs clássicos da comunidade"
              checked={settings.showMemes}
              onCheckedChange={(v) => updateSettings((s) => void (s.showMemes = v))}
            />
            {settings.showMemes && (
              <p className="mt-1 rounded-lg border border-border bg-muted/40 p-2.5 text-[11px] leading-snug text-muted-foreground">
                Com a opção ligada, o iceberg ganha espaço ao lado das camadas para as imagens —
                adicione-as no modo de edição, na área ao lado de cada camada. A opção vem
                desativada por padrão.
              </p>
            )}
          </section>

          <Separator />

          {/* ------------------ Modo de exibição ------------------ */}
          <section className="flex flex-col gap-1" aria-labelledby="opt-exibicao">
            <h3 id="opt-exibicao" className="mb-1 text-sm font-semibold">
              Modo de exibição
            </h3>

            <RowSwitch
              label="Revelar tópicos um por um"
              desc="Tópicos ficam ocultos («???») até serem revelados"
              checked={settings.revealMode}
              onCheckedChange={(v) => updateSettings((s) => void (s.revealMode = v))}
            />

            {settings.revealMode && (
              <div className="mt-2 flex flex-col gap-2.5 rounded-lg border border-border bg-muted/40 p-3">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    <strong className="text-foreground tabular-nums">{revealedCount}</strong> de{' '}
                    {total} revelados
                  </span>
                  <span className="tabular-nums">{pct}%</span>
                </div>
                <Progress value={pct} aria-label="Progresso da revelação" />
                <div className="mt-1 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => revealAll(data)}>
                    <Eye className="size-3.5" /> Revelar todos
                  </Button>
                  <Button size="sm" variant="ghost" onClick={resetReveals}>
                    <RotateCcw className="size-3.5" /> Recomeçar
                  </Button>
                </div>
                <p className="text-[11px] leading-snug text-muted-foreground">
                  Dica: use o botão flutuante «Revelar próximo» na página, ou clique num «???»
                  para revelá-lo na hora.
                </p>
              </div>
            )}
          </section>
        </div>
      </SheetContent>
    </Sheet>
  )
}

function RowSwitch({
  label,
  desc,
  checked,
  onCheckedChange,
}: {
  label: string
  desc: string
  checked: boolean
  onCheckedChange: (v: boolean) => void
}) {
  return (
    <div className="flex items-center justify-between gap-3 py-1.5">
      <div className="min-w-0">
        <p className="text-sm font-medium">{label}</p>
        <p className="text-xs text-muted-foreground">{desc}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} aria-label={label} />
    </div>
  )
}
