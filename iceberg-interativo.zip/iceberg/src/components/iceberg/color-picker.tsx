'use client'

import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  COLOR_PRESETS,
  CUSTOM_COLOR_ID,
  safeColor,
  type ColorChoice,
} from '@/lib/colors'

/**
 * Seletor de cor de texto: presets em par claro/escuro (legíveis em
 * qualquer faixa do iceberg e em qualquer tema) + cores personalizadas.
 */
export function ColorPicker({
  value,
  onChange,
  idPrefix = 'color',
}: {
  value: ColorChoice
  onChange: (cc: ColorChoice) => void
  idPrefix?: string
}) {
  const cc = safeColor(value)

  return (
    <div className="flex flex-col gap-2">
      <Select value={cc.preset} onValueChange={(v) => onChange(safeColor({ ...cc, preset: v }))}>
        <SelectTrigger id={`${idPrefix}-preset`} aria-label="Cor do texto" className="w-full">
          <SelectValue placeholder="Escolha a cor" />
        </SelectTrigger>
        <SelectContent>
          {COLOR_PRESETS.map((p) => (
            <SelectItem key={p.id} value={p.id}>
              <span className="flex items-center gap-2">
                {p.id !== 'inherit' && (
                  <span className="flex overflow-hidden rounded-full border border-border">
                    <span
                      className="size-3.5"
                      style={{ background: p.light || 'transparent' }}
                      aria-hidden
                    />
                    <span
                      className="size-3.5"
                      style={{ background: p.dark || 'transparent' }}
                      aria-hidden
                    />
                  </span>
                )}
                {p.name}
              </span>
            </SelectItem>
          ))}
          <SelectItem value={CUSTOM_COLOR_ID}>Personalizada…</SelectItem>
        </SelectContent>
      </Select>

      {cc.preset === CUSTOM_COLOR_ID && (
        <div className="grid gap-2.5 rounded-lg border border-dashed p-2.5 sm:grid-cols-2">
          <div className="grid gap-1">
            <Label htmlFor={`${idPrefix}-light`} className="text-xs">
              Sobre faixas claras
            </Label>
            <div className="flex items-center gap-1.5">
              <input
                id={`${idPrefix}-light`}
                type="color"
                value={cc.light || '#0f766e'}
                onChange={(e) => onChange(safeColor({ ...cc, light: e.target.value }))}
                aria-label="Cor personalizada para faixas claras"
                className="size-9 shrink-0 cursor-pointer rounded-md border border-border bg-transparent p-1"
              />
              <Input
                value={cc.light}
                onChange={(e) => onChange(safeColor({ ...cc, light: e.target.value }))}
                aria-label="Código da cor para faixas claras"
                className="h-9 font-mono text-xs"
                placeholder="#0f766e"
              />
            </div>
          </div>
          <div className="grid gap-1">
            <Label htmlFor={`${idPrefix}-dark`} className="text-xs">
              Sobre faixas escuras
            </Label>
            <div className="flex items-center gap-1.5">
              <input
                id={`${idPrefix}-dark`}
                type="color"
                value={cc.dark || '#5eead4'}
                onChange={(e) => onChange(safeColor({ ...cc, dark: e.target.value }))}
                aria-label="Cor personalizada para faixas escuras"
                className="size-9 shrink-0 cursor-pointer rounded-md border border-border bg-transparent p-1"
              />
              <Input
                value={cc.dark}
                onChange={(e) => onChange(safeColor({ ...cc, dark: e.target.value }))}
                aria-label="Código da cor para faixas escuras"
                className="h-9 font-mono text-xs"
                placeholder="#5eead4"
              />
            </div>
          </div>
          <p className="text-[11px] leading-snug text-muted-foreground sm:col-span-2">
            Duas cores, uma para cada situação: o texto continua legível no modo claro e no
            noturno, em qualquer profundidade do iceberg.
          </p>
        </div>
      )}

      {/* pré-visualização: como a cor fica numa faixa clara e numa escura */}
      {cc.preset !== 'inherit' && (
        <div className="grid grid-cols-2 gap-1.5" aria-hidden>
          <span
            className="flex items-center justify-center rounded-md bg-[oklch(0.96_0.01_240)] px-2 py-1.5 text-sm"
            style={{
              color: cc.preset === CUSTOM_COLOR_ID ? cc.light : COLOR_PRESETS.find((p) => p.id === cc.preset)?.light,
            }}
          >
            Faixa clara
          </span>
          <span
            className="flex items-center justify-center rounded-md bg-[oklch(0.22_0.04_228)] px-2 py-1.5 text-sm"
            style={{
              color: cc.preset === CUSTOM_COLOR_ID ? cc.dark : COLOR_PRESETS.find((p) => p.id === cc.preset)?.dark,
            }}
          >
            Faixa escura
          </span>
        </div>
      )}
    </div>
  )
}
