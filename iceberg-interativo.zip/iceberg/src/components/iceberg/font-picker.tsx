'use client'

import { useEffect } from 'react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  CUSTOM_FONT_ID,
  ensureGoogleFont,
  FONT_PRESETS,
  fontStack,
  safeFont,
  type FontChoice,
} from '@/lib/fonts'

/**
 * Seletor de fonte: presets prontos + opção personalizada
 * (nome da família e URL do Google Fonts, com pré-visualização).
 */
export function FontPicker({
  value,
  onChange,
  idPrefix = 'font',
}: {
  value: FontChoice
  onChange: (fc: FontChoice) => void
  idPrefix?: string
}) {
  const fc = safeFont(value)
  const stack = fontStack(fc)

  // carrega o Google Fonts informado, se ainda não estiver no <head>
  useEffect(() => {
    ensureGoogleFont(fc.googleUrl)
  }, [fc.googleUrl])

  return (
    <div className="flex flex-col gap-2">
      <Select value={fc.preset} onValueChange={(v) => onChange(safeFont({ ...fc, preset: v }))}>
        <SelectTrigger id={`${idPrefix}-preset`} aria-label="Fonte do texto" className="w-full">
          <SelectValue placeholder="Escolha a fonte" />
        </SelectTrigger>
        <SelectContent>
          {FONT_PRESETS.map((p) => (
            <SelectItem key={p.id} value={p.id}>
              <span style={p.stack ? { fontFamily: p.stack } : undefined}>{p.name}</span>
            </SelectItem>
          ))}
          <SelectItem value={CUSTOM_FONT_ID}>Personalizada…</SelectItem>
        </SelectContent>
      </Select>

      {fc.preset === CUSTOM_FONT_ID && (
        <div className="grid gap-2 rounded-lg border border-dashed p-2.5">
          <div className="grid gap-1">
            <Label htmlFor={`${idPrefix}-custom`} className="text-xs">
              Famílias da fonte
            </Label>
            <Input
              id={`${idPrefix}-custom`}
              value={fc.custom}
              onChange={(e) => onChange(safeFont({ ...fc, custom: e.target.value }))}
              placeholder="Ex.: Playfair Display, Georgia, serif"
              className="h-9 text-sm"
            />
          </div>
          <div className="grid gap-1">
            <Label htmlFor={`${idPrefix}-google`} className="text-xs">
              URL do Google Fonts (opcional)
            </Label>
            <Input
              id={`${idPrefix}-google`}
              value={fc.googleUrl}
              onChange={(e) => onChange(safeFont({ ...fc, googleUrl: e.target.value }))}
              placeholder="https://fonts.googleapis.com/css2?family=..."
              className="h-9 font-mono text-xs"
            />
            <p className="text-[11px] leading-snug text-muted-foreground">
              Cole o link gerado em fonts.google.com para usar uma fonte que não está no computador
              de quem visita.
            </p>
          </div>
        </div>
      )}

      {/* pré-visualização com a fonte escolhida */}
      <p
        className="rounded-md bg-muted/60 px-2.5 py-1.5 text-sm text-foreground"
        style={stack ? { fontFamily: stack } : undefined}
        aria-hidden
      >
        O rato roeu a roupa do rei de Roma — 123
      </p>
    </div>
  )
}
