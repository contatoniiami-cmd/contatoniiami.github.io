'use client'

import { useState, useSyncExternalStore } from 'react'
import { Check, MessageSquare, ThumbsDown, ThumbsUp } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { cn } from '@/lib/utils'
import {
  addSuggestion,
  getFeedback,
  getServerFeedback,
  subscribeFeedback,
  toggleDislike,
  toggleLike,
} from '@/lib/feedback-store'

/**
 * Diálogo de feedback de um tópico: like / deslike + sugestão
 * (mover de camada e/ou adicionar/remover informações).
 */
export function FeedbackDialog({
  open,
  onOpenChange,
  topicId,
  topicTitle,
  currentLayerIdx,
  layers,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  topicId: string
  topicTitle: string
  currentLayerIdx: number
  layers: { idx: number; label: string }[]
}) {
  const fb = useSyncExternalStore(subscribeFeedback, getFeedback, getServerFeedback)
  const [moveTo, setMoveTo] = useState<string>('')
  const [note, setNote] = useState('')
  const [sent, setSent] = useState(false)

  const liked = fb.likes.includes(topicId)
  const disliked = fb.dislikes.includes(topicId)

  // o formulário começa limpo a cada abertura/troca de tópico porque o
  // componente é remontado via `key` (ver <FeedbackDialog key={...} />)

  const canSend = !!moveTo || !!note.trim()

  const send = () => {
    if (!canSend) return
    const target = moveTo ? Number(moveTo) : undefined
    addSuggestion({
      topicId,
      topicTitle,
      fromLayerLabel: layers[currentLayerIdx]?.label ?? `Camada ${currentLayerIdx + 1}`,
      moveToLayerIdx: target,
      moveToLayerLabel: target !== undefined ? layers[target]?.label : undefined,
      note: note.trim(),
    })
    setSent(true)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="size-5 text-teal-600 dark:text-teal-400" aria-hidden />
            Feedback
          </DialogTitle>
          <DialogDescription className="truncate">“{topicTitle}”</DialogDescription>
        </DialogHeader>

        {sent ? (
          <div className="flex flex-col items-center gap-3 py-6 text-center">
            <span className="flex size-12 items-center justify-center rounded-full bg-teal-500/15 text-teal-600 dark:text-teal-400">
              <Check className="size-6" aria-hidden />
            </span>
            <p className="text-sm font-medium">Sugestão enviada — obrigado!</p>
            <p className="text-xs leading-snug text-muted-foreground">
              Quem estiver editando o iceberg verá a sugestão no botão Feedback do modo de
              edição.
            </p>
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
              Fechar
            </Button>
          </div>
        ) : (
          <div className="grid gap-5 py-1">
            {/* reações */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => toggleLike(topicId)}
                aria-pressed={liked}
                className={cn(
                  'flex items-center justify-center gap-2 rounded-lg border py-2.5 text-sm font-medium transition-colors',
                  liked
                    ? 'border-teal-500 bg-teal-500/15 text-teal-700 dark:text-teal-300'
                    : 'border-border hover:border-teal-400 hover:bg-teal-500/5',
                )}
              >
                <ThumbsUp className="size-4" aria-hidden />
                Gostei
              </button>
              <button
                type="button"
                onClick={() => toggleDislike(topicId)}
                aria-pressed={disliked}
                className={cn(
                  'flex items-center justify-center gap-2 rounded-lg border py-2.5 text-sm font-medium transition-colors',
                  disliked
                    ? 'border-rose-500 bg-rose-500/15 text-rose-700 dark:text-rose-300'
                    : 'border-border hover:border-rose-400 hover:bg-rose-500/5',
                )}
              >
                <ThumbsDown className="size-4" aria-hidden />
                Não gostei
              </button>
            </div>

            {/* sugestão */}
            <div className="grid gap-3 border-t border-border pt-4">
              <div className="grid gap-1.5">
                <Label className="text-sm">Sugestão (opcional)</Label>
                <p className="text-xs leading-snug text-muted-foreground">
                  Mudar o tópico de camada e/ou adicionar/remover informações dele.
                </p>
              </div>

              <div className="grid gap-1.5">
                <Select value={moveTo} onValueChange={setMoveTo}>
                  <SelectTrigger aria-label="Camada sugerida">
                    <SelectValue placeholder="Mover para outra camada…" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="keep">Não mudar de camada</SelectItem>
                    {layers.map((l) => (
                      <SelectItem key={l.idx} value={String(l.idx)} disabled={l.idx === currentLayerIdx}>
                        {l.label || `Camada ${l.idx + 1}`}
                        {l.idx === currentLayerIdx ? ' (atual)' : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-1.5">
                <Textarea
                  rows={3}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="O que adicionar ou remover neste tópico?"
                  aria-label="Sugestão de mudança no tópico"
                />
              </div>

              <Button onClick={send} disabled={!canSend} className="w-full sm:w-auto">
                Enviar sugestão
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
