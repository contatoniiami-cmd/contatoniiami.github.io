import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { ThemeProvider } from "next-themes";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ecfeff" },
    { media: "(prefers-color-scheme: dark)", color: "#082f49" },
  ],
};

export const metadata: Metadata = {
  title: "Iceberg Interativo — mergulhe no tema",
  description:
    "Um iceberg interativo e 100% editável: camadas, tópicos com fotos, descrições e links. Faça o seu e publique no GitHub Pages.",
  keywords: ["iceberg", "iceberg interativo", "iceberg chart", "GitHub Pages", "tier list"],
  authors: [{ name: "Projeto pessoal" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Iceberg Interativo",
    description: "Camadas, tópicos e histórias — clique para mergulhar.",
    siteName: "Iceberg Interativo",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}
