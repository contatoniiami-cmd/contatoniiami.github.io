'use client'

import { useEffect, useMemo, useState, useSyncExternalStore } from 'react'
import { useTheme } from 'next-themes'
import { motion } from 'framer-motion'
import {
  ArrowDown,
  ArrowUp,
  Check,
  ChevronLeft,
  ChevronRight,
  Download,
  ExternalLink,
  Eye,
  ImagePlus,
  MessageSquare,
  Pencil,
  Plus,
  RotateCcw,
  ThumbsDown,
  ThumbsUp,
  Trash2,
  X,
  ZoomIn,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { ThemeToggle } from '@/components/iceberg/theme-toggle'
import { SettingsPanel } from '@/components/iceberg/settings-panel'
import { FontPicker } from '@/components/iceberg/font-picker'
import { ColorPicker } from '@/components/iceberg/color-picker'
import { FeedbackDialog } from '@/components/iceberg/feedback-dialog'
import { useMounted } from '@/hooks/use-mounted'
import { cn } from '@/lib/utils'
import {
  depthOf,
  layerTheme,
  newId,
  topicJitter,
  topicImages,
  type IcebergData,
  type Topic,
} from '@/lib/iceberg-data'
import {
  getIceberg,
  getServerIceberg,
  resetIceberg,
  subscribeIceberg,
  updateIceberg,
} from '@/lib/iceberg-store'
import {
  bgCss,
  getSettings,
  getServerSettings,
  revealTopic,
  subscribeSettings,
  updateSettings,
} from '@/lib/settings-store'
import { DEFAULT_FONT, ensureGoogleFont, fontStack, safeFont } from '@/lib/fonts'
import { colorCss, DEFAULT_COLOR, hasColor, safeColor, type ColorChoice } from '@/lib/colors'
import {
  clearFeedback,
  getFeedback,
  getServerFeedback,
  removeSuggestion,
  subscribeFeedback,
  type Suggestion,
} from '@/lib/feedback-store'

type FormState = {
  mode: 'add' | 'edit'
  topicId?: string
  title: string
  layerIdx: number
  description: string
  images: string[]
  link: string
  font: ReturnType<typeof safeFont>
  color: ColorChoice
}

const listVariants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06, delayChildren: 0.05 } },
}

const itemVariants = {
  hidden: { opacity: 0, y: 12 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35 } },
}

/** Afunilamento máximo da silhueta (% de recuo em cada lateral, na última camada) */
const MAX_INSET = 22

/** Baixa uma imagem (blob → download); sem CORS, abre em nova aba como alternativa */
async function downloadImage(url: string, fallbackName: string) {
  const slug =
    fallbackName
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .toLowerCase() || 'imagem'
  try {
    const res = await fetch(url, { mode: 'cors' })
    if (!res.ok) throw new Error('falha ao baixar')
    const blob = await res.blob()
    let path = ''
    try {
      path = decodeURIComponent(new URL(url, window.location.href).pathname)
        .split('/')
        .filter(Boolean)
        .pop()!
    } catch {
      path = ''
    }
    const name = /\.[a-z0-9]{2,5}$/i.test(path)
      ? path
      : `${slug}.${(blob.type.split('/')[1] || 'png').replace('jpeg', 'jpg')}`
    const objUrl = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = objUrl
    a.download = name
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(objUrl)
  } catch {
    window.open(url, '_blank', 'noopener')
  }
}

export default function IcebergPage() {
  const data = useSyncExternalStore(subscribeIceberg, getIceberg, getServerIceberg)
  const settings = useSyncExternalStore(subscribeSettings, getSettings, getServerSettings)
  const { resolvedTheme } = useTheme()
  const mounted = useMounted()
  const [editMode, setEditMode] = useState(false)
  const [viewId, setViewId] = useState<string | null>(null)
  const [form, setForm] = useState<FormState | null>(null)
  const [flashId, setFlashId] = useState<string | null>(null)
  const [navDir, setNavDir] = useState<1 | -1>(1)
  const [galleryIdx, setGalleryIdx] = useState(0)
  const [lightbox, setLightbox] = useState<{ urls: string[]; idx: number; title: string } | null>(
    null,
  )
  const [feedbackFor, setFeedbackFor] = useState<string | null>(null)
  const [showFeedbackList, setShowFeedbackList] = useState(false)
  const feedback = useSyncExternalStore(subscribeFeedback, getFeedback, getServerFeedback)

  // limpa o brilho de "recém-revelado"
  useEffect(() => {
    if (!flashId) return
    const t = setTimeout(() => setFlashId(null), 1600)
    return () => clearTimeout(t)
  }, [flashId])

  // carrega fontes do Google Fonts usadas pelas configurações/tópicos
  useEffect(() => {
    ensureGoogleFont(settings.topicFont.googleUrl)
    data.layers.forEach((l) => l.topics.forEach((t) => ensureGoogleFont(t.font?.googleUrl)))
  }, [settings.topicFont.googleUrl, data])

  const update = (fn: (d: IcebergData) => void) => updateIceberg(fn)

  // ---------- navegação / revelação ----------
  const revealed = useMemo(() => new Set(settings.revealedIds), [settings.revealedIds])

  const flat = useMemo(
    () => data.layers.flatMap((l, li) => l.topics.map((t) => ({ id: t.id, layerIdx: li }))),
    [data],
  )

  const revealing = settings.revealMode && !editMode
  const navList = revealing ? flat.filter((x) => revealed.has(x.id)) : flat
  const revealedCount = flat.filter((x) => revealed.has(x.id)).length
  const hiddenCount = revealing ? flat.length - revealedCount : 0

  const isHidden = (topic: Topic) => revealing && !revealed.has(topic.id)

  const openTopic = (id: string) => {
    if (revealing && !revealed.has(id)) {
      revealTopic(id)
      setFlashId(id)
    }
    setGalleryIdx(0)
    setViewId(id)
  }

  const revealNext = () => {
    const next = flat.find((x) => !revealed.has(x.id))
    if (!next) return
    revealTopic(next.id)
    setFlashId(next.id)
    document.getElementById(`topic-${next.id}`)?.scrollIntoView({
      behavior: 'smooth',
      block: 'center',
      inline: 'center',
    })
  }

  const go = (dir: 1 | -1) => {
    if (navList.length === 0) return
    const idx = navList.findIndex((x) => x.id === viewId)
    const nextIdx = idx < 0 ? 0 : (idx + dir + navList.length) % navList.length
    setNavDir(dir)
    setGalleryIdx(0)
    setViewId(navList[nextIdx].id)
  }

  const navIdx = viewId ? navList.findIndex((x) => x.id === viewId) : -1

  const onModalKey = (e: React.KeyboardEvent) => {
    const tag = (e.target as HTMLElement).tagName
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return
    if (e.key === 'ArrowRight') {
      e.preventDefault()
      go(1)
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault()
      go(-1)
    }
  }

  const onLightboxKey = (e: React.KeyboardEvent) => {
    if (!lightbox || lightbox.urls.length < 2) return
    if (e.key === 'ArrowRight') {
      e.preventDefault()
      setLightbox((l) => (l ? { ...l, idx: (l.idx + 1) % l.urls.length } : l))
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault()
      setLightbox((l) =>
        l ? { ...l, idx: (l.idx - 1 + l.urls.length) % l.urls.length } : l,
      )
    }
  }

  /** Fonte e cor efetivas de um tópico: globais quando interligadas, individuais caso contrário */
  const styleOf = (topic: Topic, dark: boolean): React.CSSProperties | undefined => {
    const stack = settings.linkTopicFonts
      ? fontStack(settings.topicFont)
      : fontStack(topic.font)
    const color = colorCss(settings.linkTopicColors ? settings.topicColor : topic.color, dark)
    if (!stack && !color) return undefined
    return {
      ...(stack ? { fontFamily: stack } : {}),
      ...(color ? { color } : {}),
    }
  }

  // ---------- helpers de tópicos ----------
  const findTopic = (id: string): { layerIdx: number; topic: Topic } | null => {
    for (let i = 0; i < data.layers.length; i++) {
      const t = data.layers[i].topics.find((x) => x.id === id)
      if (t) return { layerIdx: i, topic: t }
    }
    return null
  }

  const openAdd = (layerIdx: number) =>
    setForm({
      mode: 'add',
      title: '',
      layerIdx,
      description: '',
      images: [],
      link: '',
      font: { ...DEFAULT_FONT },
      color: { ...DEFAULT_COLOR },
    })

  const openEdit = (topic: Topic) => {
    const found = findTopic(topic.id)
    setForm({
      mode: 'edit',
      topicId: topic.id,
      title: topic.title,
      layerIdx: found?.layerIdx ?? 0,
      description: topic.description || '',
      images: topicImages(topic),
      link: topic.link || '',
      font: safeFont(topic.font),
      color: safeColor(topic.color),
    })
  }

  const saveForm = () => {
    if (!form || !form.title.trim()) return
    update((d) => {
      const images = form.images.map((s) => s.trim()).filter(Boolean)
      const hasFont =
        form.font.preset !== 'inherit' ||
        !!form.font.custom.trim() ||
        !!form.font.googleUrl.trim()
      const payload: Topic = {
        id: form.topicId ?? newId(),
        title: form.title.trim(),
        description: form.description.trim(),
        images,
        link: form.link.trim() || undefined,
        font: hasFont ? safeFont(form.font) : undefined,
        color: hasColor(form.color) ? safeColor(form.color) : undefined,
      }
      // remove de qualquer camada (caso tenha sido movido no formulário)
      d.layers.forEach((l) => {
        l.topics = l.topics.filter((t) => t.id !== payload.id)
      })
      const target = d.layers[Math.min(form.layerIdx, d.layers.length - 1)]
      target.topics.push(payload)
    })
    setForm(null)
  }

  const deleteTopic = (id: string) => {
    if (!window.confirm('Excluir este tópico?')) return
    update((d) => {
      d.layers.forEach((l) => {
        l.topics = l.topics.filter((t) => t.id !== id)
      })
    })
    if (viewId === id) setViewId(null)
    if (form?.topicId === id) setForm(null)
  }

  const moveTopic = (id: string, dir: -1 | 1) =>
    update((d) => {
      const from = d.layers.findIndex((l) => l.topics.some((t) => t.id === id))
      const to = from + dir
      if (from < 0 || to < 0 || to >= d.layers.length) return
      const [topic] = d.layers[from].topics.splice(
        d.layers[from].topics.findIndex((t) => t.id === id),
        1,
      )
      d.layers[to].topics.push(topic)
    })

  // ---------- helpers de camadas ----------
  const updateLayer = (
    idx: number,
    patch: Partial<{ label: string; memes: string[] }>,
  ) =>
    update((d) => {
      if (d.layers[idx]) Object.assign(d.layers[idx], patch)
    })

  /** Imagens de meme (válidas) de uma camada */
  const layerMemes = (layer: { memes?: string[] }): string[] =>
    (layer.memes ?? []).map((s) => s.trim()).filter(Boolean)

  const moveLayer = (idx: number, dir: -1 | 1) =>
    update((d) => {
      const to = idx + dir
      if (to < 0 || to >= d.layers.length) return
      ;[d.layers[idx], d.layers[to]] = [d.layers[to], d.layers[idx]]
    })

  const deleteLayer = (idx: number) => {
    if (data.layers.length <= 1) return
    if (!window.confirm('Excluir esta camada e todos os tópicos dentro dela?')) return
    update((d) => {
      d.layers.splice(idx, 1)
    })
    setForm(null)
  }

  // cores rebalanceadas automaticamente: topo claro → fundo escuro
  const addLayer = () =>
    update((d) => {
      d.layers.push({ id: newId(), label: '', topics: [] })
    })

  const resetAll = () => {
    if (
      !window.confirm(
        'Restaurar o modelo em branco? Suas edições locais serão perdidas.',
      )
    )
    return
    resetIceberg()
    setViewId(null)
    setForm(null)
  }

  /** Aplica uma sugestão: move o tópico de camada (se pedida) e abre para edição */
  const applySuggestion = (s: Suggestion) => {
    const found = findTopic(s.topicId)
    if (found && s.moveToLayerIdx !== undefined && s.moveToLayerIdx !== found.layerIdx) {
      const topic = found.topic
      update((d) => {
        d.layers.forEach((l) => {
          l.topics = l.topics.filter((t) => t.id !== s.topicId)
        })
        const target = d.layers[Math.min(s.moveToLayerIdx!, d.layers.length - 1)]
        target.topics.push(topic)
      })
    }
    removeSuggestion(s.id)
    setShowFeedbackList(false)
    const after = findTopic(s.topicId)
    if (after) openEdit(after.topic)
  }

  const view = viewId ? findTopic(viewId) : null
  const dark = mounted ? resolvedTheme === 'dark' : false
  const background = bgCss(settings.bgPreset, settings.bgCustom, dark)
  const step = MAX_INSET / Math.max(data.layers.length, 1)
  const viewImages = view ? topicImages(view.topic) : []
  const viewStyle = view ? styleOf(view.topic, dark) : undefined
  const feedbackTopic = feedbackFor ? findTopic(feedbackFor) : null

  return (
    <div className="flex min-h-screen flex-col text-foreground">
      {/* fundo personalizado (fixo, atrás de tudo) */}
      <div className="fixed inset-0 -z-10" style={{ background }} aria-hidden />

      {/* ---------------- Cabeçalho ---------------- */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-2.5 px-4 py-3">
          <div className="min-w-0 flex-1">
            {editMode ? (
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                <Input
                  value={data.title}
                  onChange={(e) => updateIceberg((d) => void (d.title = e.target.value))}
                  placeholder="Título do site"
                  className="w-full bg-white/90 font-bold text-slate-900 sm:max-w-xs"
                  aria-label="Título do site"
                />
                <Input
                  value={data.subtitle}
                  onChange={(e) => updateIceberg((d) => void (d.subtitle = e.target.value))}
                  placeholder="Subtítulo (opcional)"
                  className="w-full bg-white/90 text-sm text-slate-900 sm:max-w-md"
                  aria-label="Subtítulo do site"
                />
              </div>
            ) : (
              <>
                {data.title && (
                  <h1 className="truncate text-lg font-bold sm:text-xl">{data.title}</h1>
                )}
                {data.subtitle && (
                  <p className="truncate text-xs text-muted-foreground sm:text-sm">
                    {data.subtitle}
                  </p>
                )}
              </>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant={editMode ? 'default' : 'outline'}
              size="sm"
              onClick={() => setEditMode((v) => !v)}
            >
              <Pencil className="size-4" />
              {editMode ? 'Concluir' : 'Editar'}
            </Button>
            {editMode && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFeedbackList(true)}
                title="Ver reações e sugestões recebidas"
              >
                <MessageSquare className="size-4" />
                <span className="hidden sm:inline">Feedback</span>
                {feedback.suggestions.length > 0 && (
                  <span className="ml-0.5 min-w-5 rounded-full bg-teal-500 px-1.5 text-[10px] font-bold tabular-nums text-white">
                    {feedback.suggestions.length}
                  </span>
                )}
              </Button>
            )}
            <SettingsPanel />
            <ThemeToggle />
            <Button
              variant="ghost"
              size="sm"
              onClick={resetAll}
              title="Restaurar modelo em branco"
              aria-label="Restaurar modelo em branco"
            >
              <RotateCcw className="size-4" />
            </Button>
          </div>
        </div>
        {editMode && (
          <div className="border-t border-amber-200 bg-amber-50 px-4 py-1.5 text-center text-xs text-amber-800 dark:border-amber-900 dark:bg-amber-950/60 dark:text-amber-200">
            Modo de edição: o lápis edita um tópico e as setas o movem de camada — tudo salvo
            automaticamente neste navegador. Ajustes visuais ficam em Opções.
          </div>
        )}
      </header>

      {/* ---------------- Iceberg ---------------- */}
      <main
        className={cn(
          'mx-auto w-full flex-1 px-3 py-6 sm:px-4 sm:py-10',
          settings.showMemes ? 'max-w-5xl' : 'max-w-3xl',
        )}
      >
        {settings.showSeaLevel && (
          <div className="mb-3 flex items-center gap-3 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            <span className="h-px flex-1 bg-border" aria-hidden />
            {editMode ? (
              <Input
                value={settings.seaLevelLabel}
                onChange={(e) => updateSettings((s) => void (s.seaLevelLabel = e.target.value))}
                className="h-7 w-52 bg-white/90 text-center text-[11px] tracking-wide text-slate-900"
                aria-label="Texto do nível do mar"
              />
            ) : (
              <span>{settings.seaLevelLabel}</span>
            )}
            <span className="h-px flex-1 bg-border" aria-hidden />
          </div>
        )}

        {!editMode && flat.length === 0 && (
          <div className="mb-6 rounded-xl border border-dashed border-border bg-background/60 p-6 text-center backdrop-blur">
            <p className="text-sm font-semibold">Este iceberg está em branco</p>
            <p className="mx-auto mt-1 max-w-sm text-xs leading-relaxed text-muted-foreground">
              Clique em Editar para dar um título ao site, nomear as camadas e adicionar tópicos —
              tudo é salvo automaticamente neste navegador.
            </p>
            <Button size="sm" className="mt-3" onClick={() => setEditMode(true)}>
              <Pencil className="size-4" /> Começar a editar
            </Button>
          </div>
        )}

        <div className="flex flex-col gap-1.5 sm:gap-2.5">
          {data.layers.map((layer, i) => {
            const t = layerTheme(i, data.layers.length)
            const itPct = +(i * step).toFixed(2)
            const ibPct = +((i + 1) * step).toFixed(2)
            const memes = layerMemes(layer)
            return (
              <div
                key={layer.id}
                className="flex flex-col gap-2 sm:flex-row sm:items-stretch sm:gap-3"
              >
              <motion.section
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, margin: '-60px' }}
                variants={listVariants}
                className="iceberg-layer flex-1"
                style={
                  {
                    '--it': `${itPct}%`,
                    '--ib': `${ibPct}%`,
                    background: t.background,
                  } as React.CSSProperties
                }
              >
                {/* cabeçalho da camada */}
                <motion.div
                  variants={itemVariants}
                  className="mb-1 flex flex-wrap items-center justify-center gap-x-2.5 gap-y-1 text-center"
                >
                  {editMode ? (
                    <Input
                      value={layer.label}
                      onChange={(e) => updateLayer(i, { label: e.target.value })}
                      placeholder="Nome da camada"
                      className="h-8 min-w-40 flex-1 bg-white/90 text-center text-xs text-slate-900"
                      aria-label="Nome da camada"
                    />
                  ) : (
                    <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] sm:text-xs">
                      {layer.label || (
                        <span className="font-normal italic opacity-60">Camada {i + 1}</span>
                      )}
                    </h2>
                  )}
                  {settings.showDepth && (
                    <span
                      className={cn(
                        'rounded-full border px-2 py-0.5 font-mono text-[10px]',
                        t.badge,
                      )}
                    >
                      {depthOf(i, data.layers.length)}
                    </span>
                  )}
                  {editMode && (
                    <span className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-7"
                        disabled={i === 0}
                        onClick={() => moveLayer(i, -1)}
                        title="Subir camada"
                        aria-label="Subir camada"
                      >
                        <ArrowUp className="size-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-7"
                        disabled={i === data.layers.length - 1}
                        onClick={() => moveLayer(i, 1)}
                        title="Descer camada"
                        aria-label="Descer camada"
                      >
                        <ArrowDown className="size-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-7"
                        disabled={data.layers.length <= 1}
                        onClick={() => deleteLayer(i)}
                        title="Excluir camada"
                        aria-label="Excluir camada"
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </span>
                  )}
                </motion.div>

                {/* tópicos — montagem tradicional, texto espalhado */}
                <div className="flex flex-wrap items-baseline justify-center gap-x-2 gap-y-3 pb-1 pt-2">
                  {layer.topics.map((topic) => {
                    const j = topicJitter(topic.id)
                    const hidden = isHidden(topic)
                    return (
                      <motion.div key={topic.id} variants={itemVariants} className="relative">
                        <span
                          className="inline-block"
                          style={{
                            transform: `rotate(${j.rotate.toFixed(2)}deg) translateY(${j.dy.toFixed(1)}px)`,
                            marginLeft: j.ml,
                            marginRight: j.mr,
                          }}
                        >
                          <button
                            type="button"
                            id={`topic-${topic.id}`}
                            onClick={() => openTopic(topic.id)}
                            title={hidden ? 'Clique para revelar este tópico' : topic.title}
                            aria-label={topic.title}
                            style={styleOf(topic, t.dark)}
                            className={cn(
                              'rounded-md px-2 py-1 leading-snug transition-all duration-200 hover:scale-110 hover:bg-teal-500/15 focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-hidden',
                              j.size,
                              j.weight,
                              t.label,
                              t.labelHover,
                              hidden && 'blur-[2.5px] opacity-50 select-none',
                              flashId === topic.id && 'label-flash',
                              editMode && 'outline-1 outline-dashed outline-slate-500/50 outline-offset-4',
                            )}
                          >
                            {hidden ? '???' : topic.title}
                          </button>
                        </span>
                        {editMode && (
                          <span className="absolute -right-2 -top-2 z-10 flex gap-0.5">
                            <MiniBtn
                              theme={t.mini}
                              title="Mover para a camada de cima"
                              disabled={i === 0}
                              onClick={() => moveTopic(topic.id, -1)}
                            >
                              <ArrowUp className="size-3" />
                            </MiniBtn>
                            <MiniBtn
                              theme={t.mini}
                              title="Mover para a camada de baixo"
                              disabled={i === data.layers.length - 1}
                              onClick={() => moveTopic(topic.id, 1)}
                            >
                              <ArrowDown className="size-3" />
                            </MiniBtn>
                            <MiniBtn
                              theme={t.mini}
                              title="Editar tópico"
                              onClick={() => openEdit(topic)}
                            >
                              <Pencil className="size-3" />
                            </MiniBtn>
                          </span>
                        )}
                      </motion.div>
                    )
                  })}

                  {editMode && (
                    <button
                      type="button"
                      onClick={() => openAdd(i)}
                      className={cn(
                        'flex items-center gap-1 self-center rounded-full border border-dashed px-3 py-1 text-xs transition-colors',
                        t.addBtn,
                      )}
                    >
                      <Plus className="size-3.5" />
                      tópico
                    </button>
                  )}
                </div>

                {layer.topics.length === 0 && !editMode && flat.length > 0 && (
                  <p className={cn('pt-1 text-center text-sm italic', t.sub)}>
                    Nada por aqui ainda…
                  </p>
                )}
              </motion.section>

                {/* memes da camada — coluna ao lado, alinhada com a faixa */}
                {settings.showMemes && (
                  <aside
                    aria-label={`Memes da camada ${i + 1}`}
                    className="flex w-full shrink-0 flex-row gap-2 overflow-x-auto pb-1 sm:w-40 sm:flex-col sm:overflow-visible sm:pb-0 lg:w-44"
                  >
                    {editMode ? (
                      <div className="flex w-64 flex-col gap-1.5 rounded-lg border border-dashed border-border bg-background/50 p-2 sm:w-full">
                        <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                          Memes
                        </p>
                        {(layer.memes ?? []).map((url, mi) => (
                          <div key={mi} className="flex items-center gap-1">
                            <Input
                              value={url}
                              onChange={(e) =>
                                updateLayer(i, {
                                  memes: (layer.memes ?? []).map((v, k) =>
                                    k === mi ? e.target.value : v,
                                  ),
                                })
                              }
                              className="h-7 bg-white/90 text-[11px] text-slate-900"
                              placeholder="URL da imagem"
                              aria-label={`Meme ${mi + 1} da camada ${i + 1}`}
                            />
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-7 shrink-0"
                              title="Remover meme"
                              aria-label={`Remover meme ${mi + 1}`}
                              onClick={() =>
                                updateLayer(i, {
                                  memes: (layer.memes ?? []).filter((_, k) => k !== mi),
                                })
                              }
                            >
                              <Trash2 className="size-3" />
                            </Button>
                          </div>
                        ))}
                        <button
                          type="button"
                          onClick={() =>
                            updateLayer(i, { memes: [...(layer.memes ?? []), ''] })
                          }
                          className="flex items-center justify-center gap-1 rounded-md border border-dashed border-border px-2 py-1 text-[11px] text-muted-foreground transition-colors hover:border-teal-500 hover:text-teal-600"
                        >
                          <Plus className="size-3" /> meme
                        </button>
                      </div>
                    ) : (
                      memes.map((src, mi) => (
                        <button
                          key={`${mi}-${src}`}
                          type="button"
                          title="Ampliar meme"
                          aria-label={`Ampliar meme ${mi + 1}`}
                          onClick={() =>
                            setLightbox({
                              urls: memes,
                              idx: mi,
                              title: layer.label || `Camada ${i + 1}`,
                            })
                          }
                          className="shrink-0 overflow-hidden rounded-lg border border-border shadow-sm transition-transform duration-200 hover:scale-105 focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-hidden"
                        >
                          <img
                            src={src}
                            alt=""
                            loading="lazy"
                            className="size-20 object-cover sm:aspect-square sm:size-full"
                          />
                        </button>
                      ))
                    )}
                  </aside>
                )}
              </div>
            )
          })}
        </div>

        {editMode && (
          <button
            type="button"
            onClick={addLayer}
            className="mt-4 w-full rounded-xl border-2 border-dashed border-border py-3.5 text-sm text-muted-foreground transition-colors hover:border-teal-500 hover:text-teal-600"
          >
            + Nova camada
          </button>
        )}
      </main>

      {/* ---------------- Barra flutuante: revelar tópicos ---------------- */}
      {hiddenCount > 0 && (
        <div className="fixed bottom-5 left-1/2 z-40 -translate-x-1/2">
          <motion.div
            initial={{ y: 48, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 260, damping: 24 }}
          >
            <div className="flex items-center gap-2.5 rounded-full border border-border bg-background/90 py-1.5 pl-4 pr-1.5 shadow-xl backdrop-blur">
              <span className="text-xs tabular-nums text-muted-foreground">
                {revealedCount}/{flat.length}
              </span>
              <span className="h-4 w-px bg-border" aria-hidden />
              <Button size="sm" className="rounded-full" onClick={revealNext}>
                <Eye className="size-4" />
                Revelar próximo
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      {/* ---------------- Modal: foco no tópico ---------------- */}
      <Dialog open={!!view} onOpenChange={(o) => !o && setViewId(null)}>
        <DialogContent
          className="gap-0 overflow-hidden rounded-2xl p-0 sm:max-w-3xl md:max-w-4xl"
          onKeyDown={onModalKey}
        >
          {view && (
            <motion.div
              key={view.topic.id}
              initial={{ opacity: 0, x: navDir >= 0 ? 48 : -48 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="flex max-h-[88vh] flex-col overflow-hidden"
            >
              {/* parte rolável: mídia + conteúdo */}
              <div className="min-h-0 flex-1 overflow-y-auto">
                {viewImages.length === 1 ? (
                  <button
                    type="button"
                    title="Ampliar imagem"
                    aria-label="Ampliar imagem"
                    onClick={() =>
                      setLightbox({ urls: viewImages, idx: 0, title: view.topic.title })
                    }
                    className="group relative block w-full cursor-zoom-in"
                  >
                    <img
                      src={viewImages[0]}
                      alt={view.topic.title}
                      className="aspect-video max-h-[40vh] w-full object-cover"
                    />
                    <span className="absolute right-3 top-3 flex size-9 items-center justify-center rounded-full bg-black/45 text-white opacity-0 transition-opacity group-hover:opacity-100">
                      <ZoomIn className="size-4" aria-hidden />
                    </span>
                  </button>
                ) : viewImages.length > 1 ? (
                  <div className="relative bg-black/5 dark:bg-black/30">
                    <button
                      type="button"
                      title="Ampliar imagem"
                      aria-label="Ampliar imagem"
                      onClick={() =>
                        setLightbox({ urls: viewImages, idx: galleryIdx, title: view.topic.title })
                      }
                      className="group flex w-full cursor-zoom-in items-center justify-center px-3 pt-3"
                    >
                      <img
                        src={viewImages[galleryIdx]}
                        alt={`${view.topic.title} — imagem ${galleryIdx + 1} de ${viewImages.length}`}
                        className="max-h-[36vh] w-auto max-w-full rounded-lg object-contain"
                      />
                      <span className="absolute right-3 top-3 flex size-9 items-center justify-center rounded-full bg-black/45 text-white opacity-0 transition-opacity group-hover:opacity-100">
                        <ZoomIn className="size-4" aria-hidden />
                      </span>
                    </button>
                    <span className="absolute left-3 top-3 rounded-full bg-black/45 px-2.5 py-0.5 text-xs tabular-nums text-white">
                      {galleryIdx + 1} / {viewImages.length}
                    </span>
                    <button
                      type="button"
                      aria-label="Imagem anterior"
                      onClick={() =>
                        setGalleryIdx((i) => (i - 1 + viewImages.length) % viewImages.length)
                      }
                      className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/45 p-2 text-white transition-colors hover:bg-black/70"
                    >
                      <ChevronLeft className="size-4" aria-hidden />
                    </button>
                    <button
                      type="button"
                      aria-label="Próxima imagem"
                      onClick={() => setGalleryIdx((i) => (i + 1) % viewImages.length)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/45 p-2 text-white transition-colors hover:bg-black/70"
                    >
                      <ChevronRight className="size-4" aria-hidden />
                    </button>
                    {/* miniaturas */}
                    <div className="flex gap-2 overflow-x-auto px-3 pb-3 pt-2.5">
                      {viewImages.map((src, i) => (
                        <button
                          key={`${i}-${src}`}
                          type="button"
                          onClick={() => setGalleryIdx(i)}
                          aria-label={`Ver imagem ${i + 1}`}
                          aria-current={i === galleryIdx}
                          className={cn(
                            'size-14 shrink-0 overflow-hidden rounded-md border-2 transition-all',
                            i === galleryIdx
                              ? 'border-teal-500 opacity-100'
                              : 'border-transparent opacity-60 hover:opacity-100',
                          )}
                        >
                          <img src={src} alt="" className="size-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex h-36 items-center justify-center bg-gradient-to-br from-teal-500 to-emerald-600 sm:h-44">
                    <span
                      className="select-none text-6xl font-black tracking-tight text-white/90"
                      aria-hidden
                    >
                      {view.topic.title.charAt(0).toUpperCase()}
                    </span>
                  </div>
                )}

                <div className="flex flex-col gap-5 p-6 sm:gap-6 sm:p-8">
                  <DialogHeader className="gap-2.5">
                    <DialogTitle
                      className="text-left text-2xl leading-tight sm:text-3xl"
                      style={viewStyle}
                    >
                      {view.topic.title}
                    </DialogTitle>
                    <DialogDescription className="flex flex-wrap items-center gap-2 pt-0.5 text-left">
                      <span className="rounded-full border border-border bg-muted px-2.5 py-0.5 text-xs">
                        {data.layers[view.layerIdx]?.label || `Camada ${view.layerIdx + 1}`}
                      </span>
                      {settings.showDepth && (
                        <span className="rounded-full border border-border bg-muted px-2.5 py-0.5 font-mono text-xs">
                          {depthOf(view.layerIdx, data.layers.length)}
                        </span>
                      )}
                    </DialogDescription>
                  </DialogHeader>

                  {view.topic.description ? (
                    <p className="whitespace-pre-line text-[15px] leading-7 text-muted-foreground sm:text-base">
                      {view.topic.description}
                    </p>
                  ) : (
                    <p className="text-sm italic text-muted-foreground">Sem descrição ainda.</p>
                  )}

                  {view.topic.link && (
                    <a href={view.topic.link} target="_blank" rel="noreferrer" className="no-underline">
                      <Button className="w-full sm:w-auto">
                        Saiba mais <ExternalLink className="size-4" />
                      </Button>
                    </a>
                  )}

                  {editMode && (
                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" size="sm" onClick={() => openEdit(view.topic)}>
                        <Pencil className="size-4" /> Editar
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => deleteTopic(view.topic.id)}>
                        <Trash2 className="size-4" /> Excluir
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {/* navegação entre tópicos — sempre visível */}
              <div className="flex shrink-0 items-center justify-between gap-2 border-t border-border bg-background/95 px-5 py-3 backdrop-blur sm:px-8">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => go(-1)}
                  disabled={navList.length < 2}
                >
                  <ChevronLeft className="size-4" /> Anterior
                </Button>
                <span className="flex items-center gap-2.5">
                  <span className="text-xs tabular-nums text-muted-foreground">
                    {navIdx >= 0 ? `${navIdx + 1} / ${navList.length}` : '—'}
                    <span className="ml-2 hidden text-[10px] sm:inline">← →</span>
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setFeedbackFor(view.topic.id)}
                    title="Like, deslike ou sugestão para este tópico"
                  >
                    <MessageSquare className="size-4" />
                    <span className="hidden sm:inline">Feedback</span>
                  </Button>
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => go(1)}
                  disabled={navList.length < 2}
                >
                  Próximo <ChevronRight className="size-4" />
                </Button>
              </div>
            </motion.div>
          )}
        </DialogContent>
      </Dialog>

      {/* ---------------- Modal: imagem ampliada (lightbox) ---------------- */}
      <Dialog open={!!lightbox} onOpenChange={(o) => !o && setLightbox(null)}>
        <DialogContent
          showCloseButton={false}
          aria-describedby={undefined}
          onKeyDown={onLightboxKey}
          className="w-[min(96vw,1300px)] max-w-none gap-0 overflow-visible border-none bg-transparent p-0 text-white shadow-none"
        >
          {lightbox && (
            <div className="flex flex-col items-center gap-4">
              <div className="flex w-full items-center justify-center">
                <div className="relative">
                  <img
                    src={lightbox.urls[lightbox.idx]}
                    alt={`${lightbox.title} — imagem ${lightbox.idx + 1} de ${lightbox.urls.length}`}
                    className="max-h-[74vh] w-auto max-w-full rounded-xl object-contain shadow-2xl"
                  />
                  {lightbox.urls.length > 1 && (
                    <>
                      <button
                        type="button"
                        aria-label="Imagem anterior"
                        onClick={() =>
                          setLightbox((l) =>
                            l ? { ...l, idx: (l.idx - 1 + l.urls.length) % l.urls.length } : l,
                          )
                        }
                        className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-2.5 text-white transition-colors hover:bg-black/75"
                      >
                        <ChevronLeft className="size-5" aria-hidden />
                      </button>
                      <button
                        type="button"
                        aria-label="Próxima imagem"
                        onClick={() =>
                          setLightbox((l) => (l ? { ...l, idx: (l.idx + 1) % l.urls.length } : l))
                        }
                        className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-2.5 text-white transition-colors hover:bg-black/75"
                      >
                        <ChevronRight className="size-5" aria-hidden />
                      </button>
                    </>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2 rounded-full border border-white/15 bg-black/60 px-2.5 py-1.5 backdrop-blur">
                {lightbox.urls.length > 1 && (
                  <span className="px-1.5 text-xs tabular-nums text-white/80">
                    {lightbox.idx + 1} / {lightbox.urls.length}
                  </span>
                )}
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => downloadImage(lightbox.urls[lightbox.idx], lightbox.title)}
                >
                  <Download className="size-4" /> Baixar
                </Button>
                <a
                  href={lightbox.urls[lightbox.idx]}
                  target="_blank"
                  rel="noreferrer"
                  className="no-underline"
                >
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-white hover:bg-white/15 hover:text-white"
                  >
                    Abrir em nova aba
                  </Button>
                </a>
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-white hover:bg-white/15 hover:text-white"
                  onClick={() => setLightbox(null)}
                  aria-label="Fechar imagem ampliada"
                >
                  <X className="size-4" />
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ---------------- Modal: feedback do tópico (like/deslike/sugestão) ---------------- */}
      {feedbackTopic && feedbackFor && (
        <FeedbackDialog
          key={feedbackFor}
          open
          onOpenChange={(o) => !o && setFeedbackFor(null)}
          topicId={feedbackFor}
          topicTitle={feedbackTopic.topic.title}
          currentLayerIdx={feedbackTopic.layerIdx}
          layers={data.layers.map((l, idx) => ({ idx, label: l.label }))}
        />
      )}

      {/* ---------------- Modal: feedback recebido (autor, em edição) ---------------- */}
      <Dialog open={showFeedbackList} onOpenChange={setShowFeedbackList}>
        <DialogContent className="max-h-[85vh] max-w-lg overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageSquare className="size-5 text-teal-600 dark:text-teal-400" aria-hidden />
              Feedback recebido
            </DialogTitle>
            <DialogDescription>
              Reações e sugestões enviadas neste navegador — como o site é estático, cada
              visitante vê apenas o que ele próprio enviou.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-1">
            {/* resumo de reações */}
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2 rounded-lg border border-border px-3 py-2.5">
                <ThumbsUp className="size-4 shrink-0 text-teal-600 dark:text-teal-400" aria-hidden />
                <div className="min-w-0">
                  <p className="text-sm font-semibold tabular-nums">{feedback.likes.length}</p>
                  <p className="truncate text-[11px] text-muted-foreground">gostei</p>
                </div>
              </div>
              <div className="flex items-center gap-2 rounded-lg border border-border px-3 py-2.5">
                <ThumbsDown className="size-4 shrink-0 text-rose-600 dark:text-rose-400" aria-hidden />
                <div className="min-w-0">
                  <p className="text-sm font-semibold tabular-nums">{feedback.dislikes.length}</p>
                  <p className="truncate text-[11px] text-muted-foreground">não gostei</p>
                </div>
              </div>
            </div>

            {/* sugestões */}
            <div className="grid gap-2 border-t border-border pt-4">
              <p className="text-sm font-medium">Sugestões ({feedback.suggestions.length})</p>

              {feedback.suggestions.length === 0 ? (
                <p className="rounded-lg border border-dashed border-border px-3 py-4 text-center text-xs text-muted-foreground">
                  Nenhuma sugestão por enquanto. Elas aparecem aqui quando alguém envia pelo
                  botão Feedback de um tópico.
                </p>
              ) : (
                <ul className="grid gap-2">
                  {feedback.suggestions.map((s) => {
                    const stillExists = !!findTopic(s.topicId)
                    return (
                      <li
                        key={s.id}
                        className="grid gap-2 rounded-lg border border-border bg-background/60 p-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className="min-w-0 text-sm font-medium">
                            {stillExists ? s.topicTitle : `${s.topicTitle} (tópico removido)`}
                          </p>
                          <span className="shrink-0 text-[10px] text-muted-foreground">
                            {new Date(s.date).toLocaleDateString('pt-BR')}
                          </span>
                        </div>

                        {s.moveToLayerIdx !== undefined && (
                          <p className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
                            <span className="rounded-full border border-border px-2 py-0.5">
                              {s.fromLayerLabel || 'Camada?'}
                            </span>
                            <ArrowDown className="size-3" aria-label="mover para" />
                            <span className="rounded-full border border-teal-300 bg-teal-50 px-2 py-0.5 text-teal-700 dark:border-teal-800 dark:bg-teal-950/50 dark:text-teal-300">
                              {s.moveToLayerLabel ?? `Camada ${s.moveToLayerIdx + 1}`}
                            </span>
                          </p>
                        )}

                        {s.note && (
                          <p className="whitespace-pre-line rounded-md bg-muted px-2.5 py-2 text-xs leading-snug">
                            {s.note}
                          </p>
                        )}

                        <div className="flex justify-end gap-2">
                          {stillExists && (
                            <Button size="sm" onClick={() => applySuggestion(s)}>
                              <Check className="size-3.5" /> Aplicar
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeSuggestion(s.id)}
                            aria-label="Descartar sugestão"
                          >
                            <Trash2 className="size-3.5" /> Descartar
                          </Button>
                        </div>
                      </li>
                    )
                  })}
                </ul>
              )}
            </div>
          </div>

          <DialogFooter className="flex-wrap gap-2 sm:justify-between">
            <Button
              size="sm"
              variant="ghost"
              onClick={clearFeedback}
              disabled={feedback.likes.length + feedback.dislikes.length + feedback.suggestions.length === 0}
            >
              <Trash2 className="size-4" /> Limpar tudo
            </Button>
            <Button size="sm" variant="outline" onClick={() => setShowFeedbackList(false)}>
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---------------- Modal: formulário de tópico ---------------- */}
      <Dialog open={!!form} onOpenChange={(o) => !o && setForm(null)}>
        <DialogContent className="max-h-[88vh] max-w-lg overflow-y-auto">
          {form && (
            <>
              <DialogHeader>
                <DialogTitle>{form.mode === 'add' ? 'Novo tópico' : 'Editar tópico'}</DialogTitle>
                <DialogDescription>
                  Preencha o que quiser — imagens, fonte, cor e link são opcionais.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-1">
                <div className="grid gap-1.5">
                  <Label htmlFor="f-title">Título *</Label>
                  <Input
                    id="f-title"
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    placeholder="Nome do tópico"
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label>Camada</Label>
                  <Select
                    value={String(form.layerIdx)}
                    onValueChange={(v) => setForm({ ...form, layerIdx: Number(v) })}
                  >
                    <SelectTrigger aria-label="Camada do tópico">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {data.layers.map((l, i) => (
                        <SelectItem key={l.id} value={String(i)}>
                          {l.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="f-desc">Descrição</Label>
                  <Textarea
                    id="f-desc"
                    rows={5}
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    placeholder="Conte a história por trás deste tópico…"
                  />
                </div>

                {/* imagens múltiplas */}
                <div className="grid gap-2">
                  <Label>Imagens (URLs)</Label>
                  {form.images.length === 0 && (
                    <p className="text-xs text-muted-foreground">
                      Nenhuma imagem — o tópico aparece só com texto e uma faixa colorida com a
                      inicial.
                    </p>
                  )}
                  {form.images.map((img, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <Input
                        value={img}
                        onChange={(e) =>
                          setForm((f) =>
                            f
                              ? {
                                  ...f,
                                  images: f.images.map((v, i) => (i === idx ? e.target.value : v)),
                                }
                              : f,
                          )
                        }
                        placeholder="https://exemplo.com/foto.jpg"
                        aria-label={`URL da imagem ${idx + 1}`}
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        className="size-9 shrink-0"
                        title="Remover imagem"
                        aria-label={`Remover imagem ${idx + 1}`}
                        onClick={() =>
                          setForm((f) =>
                            f ? { ...f, images: f.images.filter((_, i) => i !== idx) } : f,
                          )
                        }
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-fit"
                    onClick={() => setForm((f) => (f ? { ...f, images: [...f.images, ''] } : f))}
                  >
                    <ImagePlus className="size-4" /> Adicionar imagem
                  </Button>
                  <p className="text-[11px] leading-snug text-muted-foreground">
                    Com duas ou mais, o tópico vira uma galeria — cada imagem pode ser ampliada e
                    baixada.
                  </p>
                </div>

                {/* fonte do texto */}
                <div className="grid gap-2">
                  <Label>Fonte do texto</Label>
                  {settings.linkTopicFonts ? (
                    <div className="grid gap-2.5 rounded-lg border border-amber-300 bg-amber-50 p-3 dark:border-amber-800 dark:bg-amber-950/40">
                      <p className="text-xs leading-snug text-amber-800 dark:text-amber-200">
                        Fontes interligadas: a escolha abaixo vale para todos os tópicos. Para
                        editar a fonte só deste tópico, desative a opção em Opções.
                      </p>
                      <FontPicker
                        value={settings.topicFont}
                        onChange={(fc) => updateSettings((s) => void (s.topicFont = fc))}
                        idPrefix="f-font-all"
                      />
                    </div>
                  ) : (
                    <FontPicker
                      value={form.font}
                      onChange={(fc) => setForm((f) => (f ? { ...f, font: fc } : f))}
                      idPrefix="f-font"
                    />
                  )}
                </div>

                {/* cor do texto */}
                <div className="grid gap-2">
                  <Label>Cor do texto</Label>
                  {settings.linkTopicColors ? (
                    <div className="grid gap-2.5 rounded-lg border border-amber-300 bg-amber-50 p-3 dark:border-amber-800 dark:bg-amber-950/40">
                      <p className="text-xs leading-snug text-amber-800 dark:text-amber-200">
                        Cores interligadas: a escolha abaixo vale para todos os tópicos. Para
                        editar a cor só deste tópico, desative a opção em Opções.
                      </p>
                      <ColorPicker
                        value={settings.topicColor}
                        onChange={(cc) => updateSettings((s) => void (s.topicColor = cc))}
                        idPrefix="f-color-all"
                      />
                    </div>
                  ) : (
                    <ColorPicker
                      value={form.color}
                      onChange={(cc) => setForm((f) => (f ? { ...f, color: cc } : f))}
                      idPrefix="f-color"
                    />
                  )}
                </div>

                <div className="grid gap-1.5">
                  <Label htmlFor="f-link">Link “saiba mais” (opcional)</Label>
                  <Input
                    id="f-link"
                    value={form.link}
                    onChange={(e) => setForm({ ...form, link: e.target.value })}
                    placeholder="https://…"
                  />
                </div>
              </div>
              <DialogFooter className="mt-2 flex-wrap gap-2 sm:justify-between">
                <Button
                  variant="destructive"
                  size="sm"
                  className={form.mode === 'edit' ? '' : 'hidden'}
                  onClick={() => form.topicId && deleteTopic(form.topicId)}
                >
                  <Trash2 className="size-4" /> Excluir
                </Button>
                <span className="flex gap-2">
                  <Button variant="outline" onClick={() => setForm(null)}>
                    Cancelar
                  </Button>
                  <Button onClick={saveForm} disabled={!form.title.trim()}>
                    Salvar
                  </Button>
                </span>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function MiniBtn({
  theme,
  title,
  disabled,
  onClick,
  children,
}: {
  theme: string
  title: string
  disabled?: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      disabled={disabled}
      onClick={(e) => {
        e.stopPropagation()
        onClick()
      }}
      className={`flex size-5 items-center justify-center rounded-full border shadow transition-colors disabled:opacity-30 ${theme}`}
    >
      {children}
    </button>
  )
}
