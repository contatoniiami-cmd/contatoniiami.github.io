import { useSyncExternalStore } from 'react'

const emptySubscribe = () => () => {}

/**
 * Retorna `true` somente no cliente, após a hidratação.
 * Padrão sem efeitos (evita setState síncrono em useEffect).
 */
export function useMounted(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false,
  )
}
