// Mini-store persistente (localStorage) para os dados do iceberg.
// Padrão recomendado pelo React para estado externo: useSyncExternalStore.

import { DEFAULT_ICEBERG, STORAGE_KEY, type IcebergData } from './iceberg-data'

function loadLocal(): IcebergData | null {
  try {
    if (typeof localStorage === 'undefined') return null
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw) as IcebergData
    if (parsed && Array.isArray(parsed.layers) && parsed.layers.length > 0) {
      parsed.layers.forEach((l) => {
        if (!Array.isArray(l.topics)) l.topics = []
        // migração de dados antigos: image → images (emoji foi descontinuado)
        l.topics = l.topics.map((t) => {
          const images = t.images?.length ? t.images : t.image ? [t.image] : []
          return { ...t, images }
        })
      })
      return parsed
    }
  } catch {
    // dados corrompidos — ignora e usa o padrão
  }
  return null
}

let current: IcebergData =
  typeof window === 'undefined'
    ? DEFAULT_ICEBERG
    : (loadLocal() ?? structuredClone(DEFAULT_ICEBERG))

const listeners = new Set<() => void>()

function persist(d: IcebergData) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(d))
  } catch {
    // storage cheio/indisponível — segue sem persistir
  }
}

export function subscribeIceberg(cb: () => void): () => void {
  listeners.add(cb)
  return () => {
    listeners.delete(cb)
  }
}

export function getIceberg(): IcebergData {
  return current
}

// Snapshot estável usado no servidor e durante a hidratação
export function getServerIceberg(): IcebergData {
  return DEFAULT_ICEBERG
}

export function setIceberg(next: IcebergData) {
  current = next
  if (typeof window !== 'undefined') persist(current)
  listeners.forEach((l) => l())
}

export function updateIceberg(fn: (d: IcebergData) => void) {
  const next = structuredClone(current)
  fn(next)
  setIceberg(next)
}

export function resetIceberg() {
  setIceberg(structuredClone(DEFAULT_ICEBERG))
}
