// ============================================================
// FEEDBACK — likes, deslikes e sugestões por tópico.
// Como o site é 100% estático, tudo fica salvo no navegador de
// quem enviou; em modo de edição, o autor vê e aplica as sugestões.
// ============================================================

import { newId } from './iceberg-data'

export interface Suggestion {
  id: string
  topicId: string
  topicTitle: string
  /** rótulo da camada em que o tópico estava quando a sugestão foi feita */
  fromLayerLabel: string
  /** índice da camada sugerida (mover tópico) — undefined quando não pede mudança */
  moveToLayerIdx?: number
  /** rótulo da camada sugerida (para exibir mesmo se as camadas mudarem) */
  moveToLayerLabel?: string
  /** texto livre: o que adicionar/remover no tópico */
  note: string
  /** data de envio (ISO) */
  date: string
}

export interface FeedbackState {
  /** ids dos tópicos com like */
  likes: string[]
  /** ids dos tópicos com deslike */
  dislikes: string[]
  suggestions: Suggestion[]
}

export const FEEDBACK_KEY = 'iceberg-feedback-v1'

export const DEFAULT_FEEDBACK: FeedbackState = {
  likes: [],
  dislikes: [],
  suggestions: [],
}

function loadLocal(): FeedbackState | null {
  try {
    if (typeof localStorage === 'undefined') return null
    const raw = localStorage.getItem(FEEDBACK_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw) as Partial<FeedbackState>
    if (parsed && typeof parsed === 'object') {
      return {
        likes: Array.isArray(parsed.likes) ? parsed.likes : [],
        dislikes: Array.isArray(parsed.dislikes) ? parsed.dislikes : [],
        suggestions: Array.isArray(parsed.suggestions) ? parsed.suggestions : [],
      }
    }
  } catch {
    // corrompido — ignora
  }
  return null
}

let current: FeedbackState =
  typeof window === 'undefined'
    ? structuredClone(DEFAULT_FEEDBACK)
    : (loadLocal() ?? structuredClone(DEFAULT_FEEDBACK))

const listeners = new Set<() => void>()

function persist() {
  try {
    localStorage.setItem(FEEDBACK_KEY, JSON.stringify(current))
  } catch {
    // storage indisponível — segue sem persistir
  }
}

export function subscribeFeedback(cb: () => void): () => void {
  listeners.add(cb)
  return () => {
    listeners.delete(cb)
  }
}

export function getFeedback(): FeedbackState {
  return current
}

/** Snapshot estável para SSR/hidratação */
export function getServerFeedback(): FeedbackState {
  return DEFAULT_FEEDBACK
}

function setFeedback(next: FeedbackState) {
  current = next
  if (typeof window !== 'undefined') persist()
  listeners.forEach((l) => l())
}

/** Like: ativa/desativa; se havia deslike, remove */
export function toggleLike(topicId: string) {
  const next = structuredClone(current)
  next.dislikes = next.dislikes.filter((id) => id !== topicId)
  if (next.likes.includes(topicId)) {
    next.likes = next.likes.filter((id) => id !== topicId)
  } else {
    next.likes.push(topicId)
  }
  setFeedback(next)
}

/** Deslike: ativa/desativa; se havia like, remove */
export function toggleDislike(topicId: string) {
  const next = structuredClone(current)
  next.likes = next.likes.filter((id) => id !== topicId)
  if (next.dislikes.includes(topicId)) {
    next.dislikes = next.dislikes.filter((id) => id !== topicId)
  } else {
    next.dislikes.push(topicId)
  }
  setFeedback(next)
}

export function addSuggestion(s: Omit<Suggestion, 'id' | 'date'>) {
  const next = structuredClone(current)
  next.suggestions.push({ ...s, id: newId(), date: new Date().toISOString() })
  setFeedback(next)
}

export function removeSuggestion(id: string) {
  const next = structuredClone(current)
  next.suggestions = next.suggestions.filter((s) => s.id !== id)
  setFeedback(next)
}

export function clearFeedback() {
  setFeedback(structuredClone(DEFAULT_FEEDBACK))
}
