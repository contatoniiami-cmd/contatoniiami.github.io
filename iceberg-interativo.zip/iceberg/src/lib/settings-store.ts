// ============================================================
// CONFIGURAÇÕES VISUAIS DO ICEBERG (tema, fundo, elementos…)
// Mesmo padrão do iceberg-store: useSyncExternalStore + localStorage.
// ============================================================

import type { IcebergData } from './iceberg-data'
import { DEFAULT_FONT, type FontChoice } from './fonts'
import { DEFAULT_COLOR, safeColor, type ColorChoice } from './colors'

export type BgPreset = 'clean' | 'ocean' | 'paper' | 'aurora' | 'starry' | 'custom'

export interface Settings {
  /** Preset de fundo da página */
  bgPreset: BgPreset
  /** Cor usada quando bgPreset === 'custom' */
  bgCustom: string
  /** Mostrar a linha do nível do mar */
  showSeaLevel: boolean
  /** Texto exibido na linha do nível do mar */
  seaLevelLabel: string
  /** Mostrar o rótulo de profundidade em cada camada */
  showDepth: boolean
  /** Interligar a fonte de todos os tópicos (uma única fonte) */
  linkTopicFonts: boolean
  /** Fonte dos tópicos: vale para todos quando interligada; padrão caso contrário */
  topicFont: FontChoice
  /** Interligar a cor de texto de todos os tópicos */
  linkTopicColors: boolean
  /** Cor de texto dos tópicos: vale para todos quando interligada; padrão caso contrário */
  topicColor: ColorChoice
  /** Mostrar imagens de meme ao lado das camadas */
  showMemes: boolean
  /** Modo "revelar tópicos um por um" */
  revealMode: boolean
  /** Ids dos tópicos já revelados no modo acima */
  revealedIds: string[]
}

export const SETTINGS_KEY = 'iceberg-settings-v1'

export const DEFAULT_SETTINGS: Settings = {
  bgPreset: 'ocean',
  bgCustom: '#134e4a',
  showSeaLevel: true,
  seaLevelLabel: 'nível do mar',
  showDepth: true,
  linkTopicFonts: false,
  topicFont: { ...DEFAULT_FONT },
  linkTopicColors: false,
  topicColor: { ...DEFAULT_COLOR },
  showMemes: false,
  revealMode: false,
  revealedIds: [],
}

// Fundos prontos — cada um tem versão clara e escura
export const BG_PRESETS: Record<
  Exclude<BgPreset, 'custom'>,
  { name: string; hint: string; light: string; dark: string }
> = {
  clean: {
    name: 'Limpo',
    hint: 'cor sólida, sem distração',
    light: '#eef2f7',
    dark: '#0b1120',
  },
  ocean: {
    name: 'Oceano',
    hint: 'gradiente de água rasa a profunda',
    light: 'linear-gradient(180deg, #ecfeff 0%, #cffafe 45%, #a5f3fc 100%)',
    dark: 'linear-gradient(180deg, #082f49 0%, #155e75 55%, #0e7490 100%)',
  },
  paper: {
    name: 'Papel',
    hint: 'textura de pontinhos sutis',
    light: 'radial-gradient(#dbe4ee 1px, transparent 1px) 0 0 / 22px 22px, #f7f9fc',
    dark: 'radial-gradient(#263143 1px, transparent 1px) 0 0 / 22px 22px, #101725',
  },
  aurora: {
    name: 'Aurora',
    hint: 'brilhos suaves coloridos',
    light:
      'radial-gradient(60% 50% at 20% 0%, #ccfbf1, transparent), radial-gradient(50% 40% at 85% 15%, #ede9fe, transparent), #f8fafc',
    dark:
      'radial-gradient(60% 50% at 20% 0%, #134e4a, transparent), radial-gradient(50% 40% at 85% 15%, #312e81, transparent), #070d1b',
  },
  starry: {
    name: 'Estrelado',
    hint: 'céu com estrelinhas',
    light:
      'radial-gradient(#b9c7d8 0.8px, transparent 0.8px) 0 0 / 90px 90px, radial-gradient(#b9c7d8 0.8px, transparent 0.8px) 40px 60px / 110px 110px, #eef4fb',
    dark:
      'radial-gradient(#ffffff 0.8px, transparent 0.8px) 0 0 / 90px 90px, radial-gradient(#93c5fd 0.8px, transparent 0.8px) 40px 60px / 110px 110px, #060a18',
  },
}

/** CSS de fundo para o preset/tema atual */
export function bgCss(preset: BgPreset, custom: string, dark: boolean): string {
  if (preset === 'custom') {
    const c = custom?.trim()
    return c || (dark ? '#0b1120' : '#eef2f7')
  }
  const p = BG_PRESETS[preset]
  return dark ? p.dark : p.light
}

// ---------------- store (mesma mecânica do iceberg-store) ----------------

function loadLocal(): Settings | null {
  try {
    if (typeof localStorage === 'undefined') return null
    const raw = localStorage.getItem(SETTINGS_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw) as Partial<Settings>
    if (parsed && typeof parsed === 'object') {
      return {
        ...structuredClone(DEFAULT_SETTINGS),
        ...parsed,
        // mescla a fonte/cor com cuidado (pode ter sido salva em versão antiga)
        topicFont: { ...DEFAULT_FONT, ...(parsed.topicFont ?? {}) },
        topicColor: safeColor(parsed.topicColor),
        revealedIds: Array.isArray(parsed.revealedIds) ? parsed.revealedIds : [],
      }
    }
  } catch {
    // corrompido — usa o padrão
  }
  return null
}

let current: Settings =
  typeof window === 'undefined'
    ? structuredClone(DEFAULT_SETTINGS)
    : (loadLocal() ?? structuredClone(DEFAULT_SETTINGS))

const listeners = new Set<() => void>()

function persist(s: Settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s))
  } catch {
    // storage indisponível — segue sem persistir
  }
}

export function subscribeSettings(cb: () => void): () => void {
  listeners.add(cb)
  return () => {
    listeners.delete(cb)
  }
}

export function getSettings(): Settings {
  return current
}

/** Snapshot estável para SSR/hidratação */
export function getServerSettings(): Settings {
  return DEFAULT_SETTINGS
}

export function setSettings(next: Settings) {
  current = next
  if (typeof window !== 'undefined') persist(current)
  listeners.forEach((l) => l())
}

export function updateSettings(fn: (s: Settings) => void) {
  const next = structuredClone(current)
  fn(next)
  setSettings(next)
}

// ---------------- ações do modo "revelar" ----------------

export function revealTopic(id: string) {
  if (current.revealedIds.includes(id)) return
  updateSettings((s) => {
    s.revealedIds.push(id)
  })
}

export function revealAll(data: IcebergData) {
  const ids = data.layers.flatMap((l) => l.topics.map((t) => t.id))
  updateSettings((s) => {
    s.revealedIds = ids
  })
}

export function resetReveals() {
  updateSettings((s) => {
    s.revealedIds = []
  })
}
