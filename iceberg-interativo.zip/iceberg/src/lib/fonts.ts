// ============================================================
// FONTES — presets e personalizadas, por tópico ou interligadas
// ============================================================

/** Escolha de fonte: preset pronto OU família(s) personalizada(s) */
export interface FontChoice {
  /** id do preset (FONT_PRESETS) ou 'custom' */
  preset: string
  /** famílias digitadas pelo usuário, ex.: "Playfair Display", serif */
  custom: string
  /** URL do Google Fonts para carregar a fonte personalizada (opcional) */
  googleUrl: string
}

export const DEFAULT_FONT: FontChoice = { preset: 'inherit', custom: '', googleUrl: '' }

export const CUSTOM_FONT_ID = 'custom'

export interface FontPreset {
  id: string
  name: string
  /** pilha CSS font-family; vazio = herda a fonte do site */
  stack: string
}

/** Presets que funcionam em qualquer navegador, sem baixar nada */
export const FONT_PRESETS: FontPreset[] = [
  { id: 'inherit', name: 'Padrão do site', stack: '' },
  { id: 'georgia', name: 'Serifada clássica', stack: "Georgia, 'Times New Roman', serif" },
  { id: 'times', name: 'Times', stack: "'Times New Roman', Times, serif" },
  { id: 'arial', name: 'Arial', stack: 'Arial, Helvetica, sans-serif' },
  { id: 'verdana', name: 'Verdana', stack: 'Verdana, Geneva, sans-serif' },
  { id: 'trebuchet', name: 'Trebuchet', stack: "'Trebuchet MS', 'Segoe UI', sans-serif" },
  { id: 'impact', name: 'Impact (destaque)', stack: "Impact, 'Arial Black', sans-serif" },
  {
    id: 'comic',
    name: 'Manuscrita',
    stack: "'Comic Sans MS', 'Chalkboard SE', 'Segoe Print', cursive",
  },
  {
    id: 'mono',
    name: 'Monoespaçada',
    stack: "ui-monospace, 'Cascadia Mono', 'Courier New', monospace",
  },
]

/** Converte uma escolha em valor CSS de font-family (undefined = herdar) */
export function fontStack(fc?: FontChoice | null): string | undefined {
  if (!fc) return undefined
  if (fc.preset === CUSTOM_FONT_ID) return fc.custom?.trim() || undefined
  return FONT_PRESETS.find((p) => p.id === fc.preset)?.stack || undefined
}

/** Nome amigável da escolha (para resumos) */
export function fontName(fc?: FontChoice | null): string {
  if (!fc) return 'Padrão do site'
  if (fc.preset === CUSTOM_FONT_ID) return fc.custom?.trim() || 'Personalizada'
  return FONT_PRESETS.find((p) => p.id === fc.preset)?.name ?? 'Padrão do site'
}

/** Clona uma escolha com valores seguros */
export function safeFont(fc?: Partial<FontChoice> | null): FontChoice {
  return {
    ...DEFAULT_FONT,
    ...(fc ?? {}),
    preset: fc?.preset ?? DEFAULT_FONT.preset,
    custom: fc?.custom ?? '',
    googleUrl: fc?.googleUrl ?? '',
  }
}

/**
 * Injeta o <link> do Google Fonts no <head> (uma vez por URL).
 * Aceita apenas URLs de fonts.googleapis.com / fonts.gstatic.com.
 */
export function ensureGoogleFont(rawUrl?: string): void {
  const url = rawUrl?.trim()
  if (!url || typeof document === 'undefined') return
  let u: URL
  try {
    u = new URL(url)
  } catch {
    return
  }
  if (u.protocol !== 'https:') return
  if (u.hostname !== 'fonts.googleapis.com' && u.hostname !== 'fonts.gstatic.com') return
  if (document.querySelector(`link[data-iceberg-font="${u.href}"]`)) return
  const link = document.createElement('link')
  link.rel = 'stylesheet'
  link.href = u.href
  link.dataset.icebergFont = u.href
  document.head.appendChild(link)
}
