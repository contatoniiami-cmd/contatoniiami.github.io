// ============================================================
// DADOS DO ICEBERG — edite este arquivo para mudar o conteúdo
// Também dá para editar tudo pelo próprio site (modo Editar).
// ============================================================

import type { FontChoice } from './fonts'
import type { ColorChoice } from './colors'

// v2: modelo pessoal em branco (a versão anterior trazia conteúdo de demonstração)
export const STORAGE_KEY = 'iceberg-interativo-v2'

export interface Topic {
  id: string
  title: string
  description: string
  /** @deprecated mantido só para ler dados antigos — use images */
  image?: string
  /** URLs das imagens do tópico (galeria com zoom e download) */
  images?: string[]
  /** URL opcional "saiba mais" */
  link?: string
  /** fonte exclusiva deste tópico (ignorada quando as fontes estão interligadas) */
  font?: FontChoice
  /** cor de texto exclusiva deste tópico (ignorada quando as cores estão interligadas) */
  color?: ColorChoice
}

/** Lista de imagens de um tópico (migra o campo antigo "image") */
export function topicImages(t: Topic): string[] {
  if (t.images?.length) return t.images
  return t.image ? [t.image] : []
}

export interface Layer {
  id: string
  label: string
  topics: Topic[]
  /** imagens de "meme" exibidas ao lado da camada (opção Memes) */
  memes?: string[]
}

export interface IcebergData {
  title: string
  subtitle: string
  layers: Layer[]
}

export function newId(): string {
  return globalThis.crypto?.randomUUID?.() ?? `t-${Math.random().toString(36).slice(2, 10)}`
}

// Rótulos de profundidade exibidos em cada camada
export const DEPTH_LABELS = ['0 m', '−50 m', '−200 m', '−1 000 m', '−4 000 m', '−11 000 m']

export function depthOf(i: number, total: number): string {
  if (total > DEPTH_LABELS.length && i === total - 1) return 'fundo do mar'
  return DEPTH_LABELS[Math.min(i, DEPTH_LABELS.length - 1)]
}

// ------------------------------------------------------------
// BALANCEAMENTO DE CORES — a 1ª camada é sempre a mais clara e a
// última é sempre a mais escura, não importa quantas existam:
// a cor de cada faixa é interpolada pela posição (i / total-1).
// ------------------------------------------------------------

export interface DepthTheme {
  /** fundo CSS da faixa (oklch interpolado) */
  background: string
  /** faixa já escura? (define textos claros e botões escuros) */
  dark: boolean
  label: string
  labelHover: string
  sub: string
  badge: string
  addBtn: string
  mini: string
}

const LIGHT_CLASSES = {
  label: 'text-slate-800',
  labelHover: 'hover:text-teal-700',
  sub: 'text-slate-500',
  badge: 'border-slate-300/70 bg-white/70 text-slate-600',
  addBtn: 'border-slate-400 text-slate-600 hover:border-teal-500 hover:text-teal-700',
  mini: 'bg-white/90 text-slate-600 border-slate-300 hover:text-teal-700',
}

const DARK_CLASSES = {
  label: 'text-slate-100',
  labelHover: 'hover:text-teal-300',
  sub: 'text-slate-300',
  badge: 'border-white/25 bg-black/25 text-slate-200',
  addBtn: 'border-slate-500 text-slate-300 hover:border-teal-400 hover:text-teal-300',
  mini: 'bg-slate-900/90 text-slate-200 border-slate-600 hover:text-teal-300',
}

/** Luzidade inicial (gelo quase branco) e final (azul abissal), em OKLCH */
const L_TOP = 0.985
const L_BOTTOM = 0.155
const C_TOP = 0.008
const C_BOTTOM = 0.046
const H_TOP = 240
const H_BOTTOM = 228

export function layerTheme(i: number, total: number): DepthTheme {
  const t = total <= 1 ? 0 : i / (total - 1)
  const L = L_TOP - t * (L_TOP - L_BOTTOM)
  const C = C_TOP + t * (C_BOTTOM - C_TOP)
  const H = H_TOP - t * (H_TOP - H_BOTTOM)
  const dark = L < 0.62
  return {
    background: `oklch(${L.toFixed(3)} ${C.toFixed(3)} ${H.toFixed(1)})`,
    dark,
    ...(dark ? DARK_CLASSES : LIGHT_CLASSES),
  }
}

// ------------------------------------------------------------
// MONTAGEM TRADICIONAL — cada tópico recebe uma posição/tamanho
// "sorteado" de forma determinística (baseada no id), como nos
// icebergs clássicos: texto espalhado, levemente rotacionado e
// com pesos diferentes.
// ------------------------------------------------------------

/** Valor pseudo-aleatório estável entre -1 e 1, derivado do id */
export function hashJitter(id: string, salt: number, min: number, max: number): number {
  let h = 2166136261
  const s = `${id}:${salt}`
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  const f = ((h >>> 0) % 10007) / 10007
  return min + f * (max - min)
}

const LABEL_SIZES = ['text-[0.85rem]', 'text-[0.95rem]', 'text-[1.05rem]', 'text-[1.2rem]']
const LABEL_WEIGHTS = ['font-medium', 'font-semibold', 'font-bold']

export interface TopicJitter {
  rotate: number
  dy: number
  size: string
  weight: string
  ml: number
  mr: number
}

export function topicJitter(id: string): TopicJitter {
  return {
    rotate: hashJitter(id, 1, -3.5, 3.5),
    dy: hashJitter(id, 2, -5, 5),
    size: LABEL_SIZES[Math.floor(hashJitter(id, 3, 0, LABEL_SIZES.length))],
    weight: LABEL_WEIGHTS[Math.floor(hashJitter(id, 4, 0, LABEL_WEIGHTS.length))],
    ml: Math.round(hashJitter(id, 5, 0, 14)),
    mr: Math.round(hashJitter(id, 6, 0, 14)),
  }
}

// ------------------------------------------------------------
// MODELO PESSOAL EM BRANCO — todas as caixas começam vazias para
// você construir o seu iceberg do zero (clique em Editar).
// ------------------------------------------------------------
export const DEFAULT_ICEBERG: IcebergData = {
  title: '',
  subtitle: '',
  layers: [
    { id: 'l1', label: '', topics: [] },
    { id: 'l2', label: '', topics: [] },
    { id: 'l3', label: '', topics: [] },
    { id: 'l4', label: '', topics: [] },
  ],
}
