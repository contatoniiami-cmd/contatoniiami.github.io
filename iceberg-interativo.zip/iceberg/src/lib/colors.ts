// ============================================================
// CORES DE TEXTO — presets e personalizadas, com par claro/escuro
// para ficar legível em qualquer faixa do iceberg e em qualquer tema
// ============================================================

/** Escolha de cor: preset pronto OU cores personalizadas (claro/escuro) */
export interface ColorChoice {
  /** id do preset (COLOR_PRESETS) ou 'custom' */
  preset: string
  /** cor usada sobre faixas claras / modo claro (hex) */
  light: string
  /** cor usada sobre faixas escuras / modo escuro (hex) */
  dark: string
}

export const DEFAULT_COLOR: ColorChoice = { preset: 'inherit', light: '', dark: '' }

export const CUSTOM_COLOR_ID = 'custom'

export interface ColorPreset {
  id: string
  name: string
  /** cor para contexto claro */
  light: string
  /** cor para contexto escuro */
  dark: string
}

/**
 * Presets em pares: cada cor "light" foi escolhida para contrastar com
 * faixas de gelo quase branco; cada "dark" para contrastar com o azul
 * abissal — assim o texto nunca fica ilegível ao trocar de tema.
 */
export const COLOR_PRESETS: ColorPreset[] = [
  { id: 'inherit', name: 'Padrão', light: '', dark: '' },
  { id: 'teal', name: 'Ciano', light: '#0f766e', dark: '#5eead4' },
  { id: 'azure', name: 'Azul', light: '#1d4ed8', dark: '#93c5fd' },
  { id: 'violet', name: 'Violeta', light: '#6d28d9', dark: '#c4b5fd' },
  { id: 'rose', name: 'Rosa', light: '#be185d', dark: '#f9a8d4' },
  { id: 'amber', name: 'Âmbar', light: '#b45309', dark: '#fcd34d' },
  { id: 'red', name: 'Vermelho', light: '#b91c1c', dark: '#fca5a5' },
  { id: 'green', name: 'Verde', light: '#15803d', dark: '#86efac' },
  { id: 'slate', name: 'Grafite', light: '#334155', dark: '#cbd5e1' },
]

/**
 * Cor CSS efetiva de uma escolha.
 * @param dark true quando o contexto é escuro (faixa profunda ou tema noturno)
 * @returns undefined quando herda a cor padrão
 */
export function colorCss(cc: ColorChoice | undefined | null, dark: boolean): string | undefined {
  if (!cc) return undefined
  if (cc.preset === CUSTOM_COLOR_ID) {
    const c = (dark ? cc.dark : cc.light)?.trim()
    return c || undefined
  }
  const p = COLOR_PRESETS.find((x) => x.id === cc.preset)
  if (!p || p.id === 'inherit') return undefined
  return dark ? p.dark : p.light
}

/** Clona uma escolha com valores seguros */
export function safeColor(cc?: Partial<ColorChoice> | null): ColorChoice {
  return {
    ...DEFAULT_COLOR,
    ...(cc ?? {}),
    preset: cc?.preset ?? DEFAULT_COLOR.preset,
    light: cc?.light ?? '',
    dark: cc?.dark ?? '',
  }
}

/** Uma escolha define alguma cor? (evita salvar campos vazios) */
export function hasColor(cc?: Partial<ColorChoice> | null): boolean {
  if (!cc) return false
  if (cc.preset === CUSTOM_COLOR_ID) return !!(cc.light?.trim() || cc.dark?.trim())
  return cc.preset !== undefined && cc.preset !== 'inherit'
}
