import type { NextConfig } from "next";

// ============================================================
// GITHUB PAGES — build estático de um único site (sem servidor)
//
// Este projeto é 100% estático: basta `npm run build` e a pasta
// `out/` pode ser publicada no GitHub Pages (veja o README).
//
// BASE_PATH (opcional): se o site for publicado em
// https://usuario.github.io/NOME-DO-REPO/, defina antes do build:
//   BASE_PATH=/NOME-DO-REPO npm run build
// Para um repositório "usuario.github.io" (site na raiz), deixe
// sem BASE_PATH.
// ============================================================
const basePath = process.env.BASE_PATH?.replace(/\/+$/, "") || "";

const nextConfig: NextConfig = {
  output: "export",
  basePath: basePath || undefined,
  assetPrefix: basePath || undefined,
  trailingSlash: true,
  images: { unoptimized: true },
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
