# 🧊 Iceberg Interativo

Um site de iceberg no estilo dos clássicos da internet — **navegável e 100% editável**.
Este é o seu **template pessoal em branco**: todas as caixas começam vazias para você
construir o seu iceberg do zero, e tudo está pronto para publicar no **GitHub Pages**.

## ✨ O que ele faz

| Recurso | Onde |
| --- | --- |
| 🖼️ **Montagem tradicional** | Camadas em silhueta que afunilam para o fundo do mar; tópicos escritos direto no gelo, com posição, tamanho e leve rotação próprios |
| 🌈 **Cores balanceadas** | A 1ª camada é sempre a mais clara e a última a mais escura, não importa quantas existam |
| ✏️ **Editor completo** | Botão **Editar**: título, subtítulo, camadas, tópicos (descrição, imagens, link, fonte e cor) — salvo automaticamente no navegador |
| 🎨 **Cores de texto à prova de tema** | Presets em par claro/escuro + cores personalizadas para cada situação: o texto fica legível no modo claro e no noturno, em qualquer profundidade |
| 🔤 **Fontes padrões e personalizadas** | Por tópico ou interligadas para todos; aceita URL do Google Fonts |
| 🧌 **Memes por camada** | Opção **desativada por padrão** em ⚙️ Opções; ao ativar, cada camada ganha uma coluna lateral de imagens, com layout realinhado para caber tudo |
| 💬 **Feedback por tópico** | No modal do tópico: **Gostei / Não gostei** e **sugestão** (mover de camada e/ou adicionar/remover informações). Em modo de edição, o botão **Feedback** lista tudo com **Aplicar / Descartar** |
| 🌙 **Modo escuro integrado** | Claro / Escuro / Sistema, lembrado no navegador |
| 🔍 **Foco no tópico** | Ao clicar: fundo embaçado + modal grande, navegação **« Anterior / Próximo »** (setas do teclado funcionam) |
| 🖼️ **Galeria de imagens** | Várias imagens por tópico, ampliação em lightbox e botão de **baixar** |
| 👀 **Revelar um por um** | Tópicos viram «???» até serem revelados, com barra de progresso |
| ⚙️ **Personalização visual** | Fundos (Limpo, Oceano, Papel, Aurora, Estrelado ou cor própria), nível do mar, profundidade |

> ℹ️ Como o site é 100% estático, o feedback e as edições ficam salvos **no navegador**
> de quem enviou. Para "publicar" uma edição sua de forma permanente, edite
> `src/lib/iceberg-data.ts` (veja abaixo).

## 📁 O que vem nesta pasta

| Caminho | O que é |
| --- | --- |
| `src/` | O código-fonte do site (Next.js + React + Tailwind) |
| `site-pronto/` | O site **já compilado** — abra o `index.html` ou publique a pasta inteira |
| `.github/workflows/deploy.yml` | Publica automaticamente no GitHub Pages a cada push |
| `package.json` | Dependências (apenas as necessárias) |

## 🚀 Publicar no GitHub Pages

### Jeito automático (recomendado)

1. Crie um repositório público em [github.com/new](https://github.com/new)
   (ex.: `meu-iceberg` — ou `SEU-USUARIO.github.io` para virar seu site principal).
2. Suba **o conteúdo desta pasta** (o código-fonte) para o repositório:
   ```bash
   git init
   git add .
   git commit -m "Meu iceberg"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/meu-iceberg.git
   git push -u origin main
   ```
3. No GitHub, vá em **Settings → Pages** e mude **Source** para **GitHub Actions**.
4. Pronto: a cada push no `main`, o workflow compila e publica sozinho.
   O site fica em `https://SEU-USUARIO.github.io/meu-iceberg/`.

O workflow já detecta sozinho se o repositório é um projeto (usa o caminho
`/nome-do-repo`) ou um site `usuario.github.io` (publica na raiz).

### Jeito manual (sem compilar nada)

1. Crie um repositório público.
2. Suba **apenas o conteúdo da pasta `site-pronto/`** (arraste os arquivos em
   *Add file → Upload files*).
3. **Settings → Pages** → Source: **Deploy from a branch** → `main` → `/ (root)` → **Save**.

## ✏️ Como construir o seu iceberg

**Pelo site (jeito fácil):** abra o site e clique em **Editar** —
dê título e subtítulo, renomeie as camadas, adicione tópicos com **＋ tópico**,
movam-se entre camadas com ↑ ↓, e use **+ Nova camada** quando precisar.
As preferências visuais ficam em **⚙️ Opções** (fundos, fontes, cores, memes,
nível do mar, profundidade, modo revelar).

Tudo é salvo no navegador (localStorage). O botão **↺** restaura o modelo em branco.

**No código (jeito permanente):** edite `src/lib/iceberg-data.ts`:

```ts
export const DEFAULT_ICEBERG: IcebergData = {
  title: 'Título do seu iceberg',
  subtitle: 'Um subtítulo',
  layers: [
    {
      id: 'l1',
      label: 'Superfície',
      topics: [
        {
          id: 't1',
          title: 'Um tópico',
          description: 'A descrição dele…',
          images: ['https://exemplo.com/foto.jpg'],
          link: 'https://exemplo.com/saiba-mais',
        },
      ],
      memes: ['https://exemplo.com/meme.png'], // opcional (aparece com a opção Memes ligada)
    },
  ],
}
```

Dica de fluxo: monte tudo pelo site → abra o **DevTools (F12) → Application →
Local Storage** → copie o valor de `iceberg-interativo-v2` → cole as camadas/tópicos
no `DEFAULT_ICEBERG` → suba para o GitHub. Assim o conteúdo passa a ser o padrão
para todo visitante.

## 🛠️ Rodar e compilar localmente

```bash
npm install     # instalar dependências
npm run dev     # desenvolvimento em http://localhost:3000
npm run build   # compilar para a pasta out/ (pronta para GitHub Pages)
```

Se o site for publicado em `https://usuario.github.io/NOME-DO-REPO/`, compile com:

```bash
BASE_PATH=/NOME-DO-REPO npm run build
```

## ℹ️ Notas

- O `site-pronto/` inclui um arquivo `.nojekyll` (necessário no GitHub Pages).
- Em telas pequenas o layout se adapta sozinho; a coluna de memes vira uma
  faixa horizontal rolável.
- Feito com Next.js 16, React 19, Tailwind CSS 4 e framer-motion.
